﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LoginForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.UNLabel = New System.Windows.Forms.Label()
        Me.PWLabel = New System.Windows.Forms.Label()
        Me.PWTextBox = New System.Windows.Forms.TextBox()
        Me.UserIDTextBox = New System.Windows.Forms.TextBox()
        Me.OKButton = New System.Windows.Forms.Button()
        Me.CancelButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'UNLabel
        '
        Me.UNLabel.AutoSize = True
        Me.UNLabel.Location = New System.Drawing.Point(58, 358)
        Me.UNLabel.Name = "UNLabel"
        Me.UNLabel.Size = New System.Drawing.Size(89, 25)
        Me.UNLabel.TabIndex = 0
        Me.UNLabel.Text = "User ID:"
        Me.UNLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PWLabel
        '
        Me.PWLabel.AutoSize = True
        Me.PWLabel.Location = New System.Drawing.Point(45, 425)
        Me.PWLabel.Name = "PWLabel"
        Me.PWLabel.Size = New System.Drawing.Size(112, 25)
        Me.PWLabel.TabIndex = 1
        Me.PWLabel.Text = "Password:"
        Me.PWLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PWTextBox
        '
        Me.PWTextBox.Location = New System.Drawing.Point(174, 419)
        Me.PWTextBox.Name = "PWTextBox"
        Me.PWTextBox.Size = New System.Drawing.Size(371, 31)
        Me.PWTextBox.TabIndex = 2
        Me.PWTextBox.UseSystemPasswordChar = True
        '
        'UserIDTextBox
        '
        Me.UserIDTextBox.Location = New System.Drawing.Point(174, 352)
        Me.UserIDTextBox.Name = "UserIDTextBox"
        Me.UserIDTextBox.Size = New System.Drawing.Size(150, 31)
        Me.UserIDTextBox.TabIndex = 3
        '
        'OKButton
        '
        Me.OKButton.Location = New System.Drawing.Point(108, 525)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.Size = New System.Drawing.Size(124, 66)
        Me.OKButton.TabIndex = 4
        Me.OKButton.Text = "&Log &In"
        Me.OKButton.UseVisualStyleBackColor = True
        '
        'CancelButton
        '
        Me.CancelButton.Location = New System.Drawing.Point(391, 525)
        Me.CancelButton.Name = "CancelButton"
        Me.CancelButton.Size = New System.Drawing.Size(124, 66)
        Me.CancelButton.TabIndex = 5
        Me.CancelButton.Text = "&Cancel"
        Me.CancelButton.UseVisualStyleBackColor = True
        '
        'LoginForm
        '
        Me.AcceptButton = Me.OKButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(617, 656)
        Me.Controls.Add(Me.CancelButton)
        Me.Controls.Add(Me.OKButton)
        Me.Controls.Add(Me.UserIDTextBox)
        Me.Controls.Add(Me.PWTextBox)
        Me.Controls.Add(Me.PWLabel)
        Me.Controls.Add(Me.UNLabel)
        Me.Name = "LoginForm"
        Me.ShowIcon = False
        Me.Text = "Login"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents UNLabel As Label
    Friend WithEvents PWLabel As Label
    Friend WithEvents PWTextBox As TextBox
    Friend WithEvents UserIDTextBox As TextBox
    Friend WithEvents OKButton As Button
    Friend WithEvents CancelButton As Button
End Class
