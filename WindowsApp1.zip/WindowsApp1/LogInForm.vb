﻿Public Class LoginForm
    Private DB As New DBAccess

    Private Sub OKButton_Click(sender As Object, e As EventArgs) Handles OKButton.Click

        If UserIDTextBox.Text = String.Empty Then
            MessageBox.Show("User ID should not be empty!")
            UserIDTextBox.Select()
            Exit Sub

        Else
            If PWTextBox.Text = String.Empty Then
                MessageBox.Show("Password shout not be empty!")
                PWTextBox.Select()
                Exit Sub

            Else
                DB.AddParam("@userid", UserIDTextBox.Text)
                DB.AddParam("@userpassword", PWTextBox.Text)
                DB.ExecuteQuery("Select * from user where userid = ? and userpassword = ?")

                If DB.Exception <> String.Empty Then
                    MessageBox.Show(DB.Exception)
                    Exit Sub
                Else
                    If DB.RecordCount = 0 Then
                        MessageBox.Show("The user ID and password do not match.")
                        Exit Sub
                    Else
                        'Bring User ID to other screens
                        Dim obj As New HomeForm
                        obj.stringpass = UserIDTextBox.Text
                        obj.Show()
                        Me.Close()
                        'homeForm.Show()
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub CancelButton_Click(sender As Object, e As EventArgs) Handles CancelButton.Click
        Me.Close()
    End Sub
    Private Sub LoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
