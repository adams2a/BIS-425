﻿Public Class HomeForm
    Public Property StringPass As String
    Private Sub HomeForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        UserIDLabel.Text = StringPass
    End Sub

End Class