﻿Imports System.Data.Odbc
Imports System.Data
Imports System.Data.SqlClient
Public Class DBAccess

    Private ConnectionString As String = "Driver={MySQL ODBC 5.3 ANSI Driver};SERVER=141.209.241.47;DATABASE=DBAccess;USER=bis425c2g2;PASSWORD=firstpass"

    Private DBConnection As New OdbcConnection(ConnectionString)
    Public DBReader As OdbcDataReader
    Public DBCommand As New OdbcCommand

    'DB Data. Make them public. Access needed from presentation tier. 

    Public DBDataAdapter As OdbcDataAdapter

    Public DBDataTable As DataTable

    'query parameters

    Public Params As New List(Of OdbcParameter)

    'query statistics

    Public RecordCount As Integer

    Public Exception As String

    'create general procedure to execute database queries. SQL Strings are passed to the query as argument.

    Public Sub ExecuteQuery(QueryString As String)
        'reset query stats
        RecordCount = 0
        Exception = String.Empty

        Try
            'open a data connection
            DBConnection.Open()

            'create database command
            DBCommand = New OdbcCommand(QueryString, DBConnection)

            'load aparameters into DBCOmmand
            For Each p As OdbcParameter In Params
                DBCommand.Parameters.Add(p)
            Next
            Params.Clear()

            'execute commands and fill database
            DBDataTable = New DataTable
            DBDataAdapter = New OdbcDataAdapter(DBCommand)

            RecordCount = DBDataAdapter.Fill(DBDataTable)


        Catch ex As Exception
            'Carry message into presentation tier
            Exception = ex.Message
        End Try

        If DBConnection.State = ConnectionState.Open Then
            DBConnection.Close()
        End If

    End Sub
    'Procedure to accept parameters for queries
    Public Sub AddParam(Name As String, Value As Object)
        Dim NewParam As New OdbcParameter(Name, Value)
        Params.Add(NewParam)
    End Sub
End Class
