﻿Public Class Person_PreviewForm
    Private Sub Person_Preview_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        NewPersonForm.Show()
        Me.Text = NewPersonForm.PersonClientTextBox.Text
    End Sub

    Private Sub Person_PreviewForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PersonClientTextBox.Text = NewPersonForm.PersonClientTextBox.Text
        PersonIDTextBox.Text = NewPersonForm.PersonIDTextBox.Text
        PasswordTextBox.Text = NewPersonForm.PasswordTextBox.Text
        DateAddedTextBox.Text = NewPersonForm.CreateDateTimePicker.Value
        NameTextBox.Text = NewPersonForm.PersonFNTextBox.Text
        DOBTextBox.Text = NewPersonForm.PersonDOBDateTimePicker.Value
        PersonAgeTextBox.Text = NewPersonForm.PersonAgeTextBox.Text
        PersonEmailTextBox.Text = NewPersonForm.PersonEmailTextBox.Text
        BranchIDTextBox.Text = NewPersonForm.PersonBranchIDComboBox.Text
        GenderTextBox.Text = NewPersonForm.PersonGenderComboBox.Text
        PersonPhoneMaskedTextBox.Text = NewPersonForm.PersonPhoneMaskedTextBox.Text
        PersonTypeTextBox.Text = NewPersonForm.PersonTypeComboBox.Text
        PersonStreetTextBox.Text = NewPersonForm.PersonStreetTextBox.Text
        PersonCityTextBox.Text = NewPersonForm.PersonCityTextBox.Text
        StateTextBox.Text = NewPersonForm.PersonStateComboBox.Text
        ZipTextBox.Text = NewPersonForm.PersonZipMaskedTextBox.Text
        ContactFNTextBox.Text = NewPersonForm.ContactFNTextBox.Text
        ContactLNTextBox.Text = NewPersonForm.ContactLNTextBox.Text
        PhoneMaskedTextBox.Text = NewPersonForm.PhoneMaskedTextBox.Text
    End Sub

End Class