﻿Public Class PersonsForm
    Private DB As New DBAccess
    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function

    Public Sub RefreshDB()
        DB.ExecuteQuery("SELECT * FROM person ORDER BY PersonID ASC")
        If NotEmpty(DB.Exception) Then
            MessageBox.Show(DB.Exception)
            Exit Sub
        End If
        PersonDataGridView.DataSource = DB.DBDataTable
    End Sub
    Public Sub RefreshComboBox()
        PersonComboBox.Items.Clear()
        PersonComboBox.Text = ""
        For Each ADataRow As DataRow In DB.DBDataTable.Rows
            PersonComboBox.Items.Add(ADataRow("PersonLastName") & ", " &
ADataRow("PersonFirstName"))
        Next
        'display no customer
        If DB.RecordCount > 0 Then
            PersonComboBox.SelectedIndex = -1
        End If
    End Sub

    Private Sub PersonsForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PersonDataGridView.ReadOnly = True
        RefreshDB()
        RefreshComboBox()
    End Sub

    Private Sub SearchPerson(PersonLastName As String)
        DB.AddParam("@PersonLastName", PersonLastName & "%")
        DB.ExecuteQuery("SELECT * FROM person WHERE PersonLastName LIKE ?")
        If NotEmpty(DB.Exception) Then
            MessageBox.Show(DB.Exception)
            Exit Sub
        End If
        'fill data grid
        PersonDataGridView.DataSource = DB.DBDataTable
        RefreshComboBox()
    End Sub
    Private Sub SelectPerson(PersonLastName As String, PersonFirstName As String)
        DB.AddParam("@PersonFirstName", PersonFirstName)
        DB.AddParam("@PersonLastname", PersonLastName)
        DB.ExecuteQuery("SELECT PersonID, PersonFirstName, PersonLastName FROM person WHERE PersonFirstName = ? AND PersonLastName = ?")
        If NotEmpty(DB.Exception) OrElse DB.RecordCount < 1 Then
            If NotEmpty(DB.Exception) Then
                MessageBox.Show(DB.Exception)
            End If
            Exit Sub
        End If
        Dim SearchedRow As DataRow = DB.DBDataTable.Rows(0)
        PersonIDTextBox.Text = SearchedRow!PersonID.ToString
        PersonNameTextBox.Text = SearchedRow!PersonLastName.ToString & ", " &
       SearchedRow!PersonFirstName.ToString
        DeletePersonToolStripMenuItem.Enabled = True
    End Sub
    Private Sub DeletePerson()
        If MessageBox.Show("Are you sure that you want to delete the selected person's record?", "Delete Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = vbNo Then

            Exit Sub
        End If
        DB.AddParam("@PersonID", PersonIDTextBox.Text)
        DB.ExecuteQuery("DELETE FROM person WHERE PersonID = ?")
        If NotEmpty(DB.Exception) Then
            MessageBox.Show(DB.Exception)
            Exit Sub
        End If
        PersonIDTextBox.Clear()
        PersonNameTextBox.Clear()
        DeletePersonToolStripMenuItem.Enabled = False
        RefreshDB()
        RefreshComboBox()
    End Sub
    Private Sub SearchButton_Click(sender As System.Object, e As System.EventArgs) Handles SearchButton.Click
        SearchPerson(SearchPersonTextBox.Text)
    End Sub
    Private Sub NewCustomerToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles NewPersonToolStripMenuItem.Click
        Me.Close()
        NewPersonForm.Show()
    End Sub
    Private Sub customersDataGridView_CellClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles PersonDataGridView.CellClick

        If e.ColumnIndex < 0 Or e.RowIndex < 0 Then
            Exit Sub
        End If
        SelectPerson(PersonDataGridView.Item(3, e.RowIndex).Value,
PersonDataGridView.Item(2, e.RowIndex).Value)
    End Sub
    Private Sub DBComboBox_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles PersonComboBox.SelectedIndexChanged
        If Not String.IsNullOrEmpty(PersonComboBox.Text) Then
            Dim NameArray() As String
            NameArray = Split(PersonComboBox.Text, ", ")
            SelectPerson(NameArray(0), NameArray(1))
        End If
    End Sub
    Private Sub DeleteCustomerToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles DeletePersonToolStripMenuItem.Click
        DeletePerson()
    End Sub
    Private Sub EditCustomerToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles EditPersonToolStripMenuItem.Click
        Person_EditFormvb.Show()
    End Sub

    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub SearchPersonTextBox_TextChanged(sender As Object, e As EventArgs) Handles SearchPersonTextBox.TextChanged

    End Sub
End Class