﻿Imports System.Data.Common
Public Class NewPersonForm
    Private DB As New DBAccess
    Public SQLString As String
    Public DBreader As String
    Private currentreccord As Integer = 0
    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function
    Private Sub NewPersonForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PersonDataGridView.Enabled = False
        PersonDataGridView.ReadOnly = True
        CreateDateTimePicker.Enabled = False
        UpdateDateTimePicker.Enabled = False

        DB.ExecuteQuery("Select (PersonID, PersonClient, BranchID, PersonFirstName, PersonMiddleInitial, PersonLastName, PersonGender, PersonPhoneNumber, PersonBirthDate, PersonAge, PersonType, PersonPassword, PersonEmail, PersonStreet, PersonCity, PersonZip, PersonState, EmergencyFirstName, EmergencyLastName, EmergencyPhoneNumber, AddedBy, CreateDate) From person")
        DB.ExecuteQuery("Select * From person")

        If DB.Exception <> String.Empty Then
            MessageBox.Show(DB.Exception)
            Exit Sub
        End If
        'Fill data grid. 
        PersonDataGridView.DataSource = DB.DBDataTable
        'Show user logged in
        AddedByTextBox.Text = UserID.ToString

        'enable/disable person information
        PersonFNTextBox.ReadOnly = True
        PersonMiddleTextBox.ReadOnly = True
        PersonLNTextBox.ReadOnly = True
        PersonDOBDateTimePicker.Enabled = False
        PersonBranchIDComboBox.Enabled = False
        PersonGenderComboBox.Enabled = False
        PersonPhoneMaskedTextBox.Enabled = False
        PersonEmailTextBox.ReadOnly = True
        PersonPasswordTextBox.Enabled = False
        PersonTypeComboBox.Enabled = False

        'Enable/Disable User Address
        PersonStreetTextBox.ReadOnly = True
        PersonCityTextBox.ReadOnly = True
        PersonStreetTextBox.ReadOnly = True
        PersonZipMaskedTextBox.ReadOnly = True
        'Emergency Contact
        ContactFNTextBox.ReadOnly = True
        ContactLNTextBox.ReadOnly = True
        PhoneMaskedTextBox.Enabled = False
        'enable/disable user access info
        PersonClientTextBox.ReadOnly = True
        PersonIDTextBox.ReadOnly = True
        PasswordTextBox.ReadOnly = True
        CreateDateTimePicker.Enabled = False
        LastUpdatedByTextBox.ReadOnly = True

        'enable/disable buttons
        SaveButton.Enabled = False
    End Sub
    Private Sub CancelButton_Click(sender As Object, e As EventArgs) Handles CancelButton.Click
        PersonFNTextBox.Clear()
        PersonMiddleTextBox.Clear()
        PersonLNTextBox.Clear()
        PersonDOBDateTimePicker.Value = Today
        PersonAgeTextBox.Clear()
        PersonEmailTextBox.Clear()
        PersonBranchIDComboBox.SelectedIndex = -1
        PersonGenderComboBox.SelectedIndex = -1
        PersonPhoneMaskedTextBox.Text = String.Empty
        PersonTypeComboBox.SelectedText = -1
        PersonPasswordTextBox.Text = ""
        PersonStreetTextBox.Text = ""
        PersonCityTextBox.Clear()
        PersonStateComboBox.SelectedIndex = -1
        PersonZipMaskedTextBox.Text = String.Empty
        ContactFNTextBox.Clear()
        ContactLNTextBox.Clear()
        PhoneMaskedTextBox.Clear()
        PersonIDTextBox.Clear()
        PasswordTextBox.Clear()
        PersonClientTextBox.Clear()

        'enable/disable buttons
        AddButton.Enabled = True
        SaveButton.Enabled = False
        ExitButton.Enabled = True
    End Sub
    Private Sub AddButton_Click(sender As Object, e As EventArgs) Handles AddButton.Click
        'disable datagrid cell click
        PersonDataGridView.Enabled = False
        'enable/disable buttons
        SaveButton.Enabled = False

        'Enable/Disable User Information
        PersonFNTextBox.ReadOnly = False
        PersonMiddleTextBox.ReadOnly = False
        PersonLNTextBox.ReadOnly = False
        PersonDOBDateTimePicker.Enabled = True
        PersonBranchIDComboBox.Enabled = True
        PersonGenderComboBox.Enabled = True
        PersonPhoneMaskedTextBox.Enabled = True
        PersonEmailTextBox.ReadOnly = False
        PersonPasswordTextBox.Enabled = True
        PersonTypeComboBox.Enabled = True
        'Enable/Disable User Address
        PersonStreetTextBox.ReadOnly = False
        PersonCityTextBox.ReadOnly = False
        PersonStreetTextBox.ReadOnly = False
        PersonZipMaskedTextBox.ReadOnly = False
        'Emergency Contact
        ContactFNTextBox.ReadOnly = False
        ContactLNTextBox.ReadOnly = False
        PhoneMaskedTextBox.Enabled = True
        'enable/disable user access info
        PersonClientTextBox.ReadOnly = True
        PersonIDTextBox.ReadOnly = True
        PasswordTextBox.ReadOnly = True
        CreateDateTimePicker.Enabled = False
        LastUpdatedByTextBox.ReadOnly = True
        AddedByTextBox.Text = UserID

        'Record new user's user ID
        If PersonFNTextBox.Text = "" Then
            MessageBox.Show(String.Format("Please enter the following information before moving on:" & vbNewLine & "-First name:" & vbNewLine & "-Middle inital" & vbNewLine & "-Last name:" & vbNewLine & "-Person DOB:" & vbNewLine & "Valid Email Address." & vbNewLine & "-Branch ID:" & vbNewLine & "-Gender:" & vbNewLine & "-Phone Number:" & vbNewLine & "-Person Type:" & vbNewLine & "-Address" & vbNewLine & "-Emergency Contact Information", MessageBoxButtons.OK))
            PersonFNTextBox.Focus()
        ElseIf PersonFNTextBox.Text = "" Then
            MessageBox.Show(String.Format("First Name cannot be left emptpy!", MessageBoxButtons.OK))
            PersonFNTextBox.Focus()
        ElseIf PersonMiddleTextBox.Text = "" Then
            MessageBox.Show("Middle Initial cannot be left empty!")
            PersonMiddleTextBox.Focus()
        ElseIf PersonLNTextBox.Text = "" Then
            MessageBox.Show("Last Name cannot be left emptpy!")
            PersonLNTextBox.Focus()
        ElseIf PersonDOBDateTimePicker.Value = Now Then
            MessageBox.Show("Date of birth cannot be left empty!")
            PersonDOBDateTimePicker.Focus()
        ElseIf PersonAgeTextBox.Text = "" Then
            MessageBox.Show("birthdate cannot be left empty")
            PersonDOBDateTimePicker.Focus()
        ElseIf PersonEmailTextBox.Text = "" Then
            MessageBox.Show("Please enter a valid email address")
            PersonEmailTextBox.Focus()
        ElseIf PersonBranchIDComboBox.Text = "" Then
            MessageBox.Show("Branch ID cannot be left empty!")
            PersonBranchIDComboBox.Focus()
        ElseIf PersonGenderComboBox.Text = "" Then
            MessageBox.Show("Gender cannot be left blank!")
            PersonGenderComboBox.Focus()
        ElseIf PersonPhoneMaskedTextBox.Text = "" Then
            MessageBox.Show("Phone number cannot be left blank!")
            PersonPhoneMaskedTextBox.Focus()
        ElseIf PersonTypeComboBox.Text = "" Then
            MessageBox.Show("Person type cannot be left blank!")
            PersonTypeComboBox.Focus()
        ElseIf PersonPasswordTextBox.Text = "" Then
            MessageBox.Show("You must enter a password to continue saving this person.")
            PersonPasswordTextBox.Focus()
            'Person Address group box
        ElseIf PersonStreetTextBox.Text = "" Then
            MessageBox.Show("Street address cannot be left empty!")
            PersonStreetTextBox.Focus()
        ElseIf PersonCityTextBox.Text = "" Then
            MessageBox.Show("City cannot be left empty")
            PersonCityTextBox.Focus()
        ElseIf PersonStateComboBox.Text = "" Then
            MessageBox.Show("State cannot be left empty!")
            PersonStateComboBox.Focus()
        ElseIf PersonZipMaskedTextBox.Text = "" Then
            MessageBox.Show("Zipcode cannot be left empty")
            PersonZipMaskedTextBox.Focus()
        ElseIf ContactFNTextBox.Text = "" Then
            MessageBox.Show("Please enter emergency contact first name")
            ContactFNTextBox.Focus()
        ElseIf ContactLNTextBox.Text = "" Then
            MessageBox.Show("Please enter emergency contact last name")
            ContactLNTextBox.Focus()
        ElseIf PhoneMaskedTextBox.Text = String.Empty Then
            MessageBox.Show("Please enter emergency contact first name")
            PhoneMaskedTextBox.Focus()
        Else
            'Populate Person Access Infor
            PersonIDTextBox.Text = PersonLNTextBox.Text.Substring(0, 5) + "1" + PersonFNTextBox.Text.Substring(0, 1)
            PasswordTextBox.Text = PersonPasswordTextBox.Text

            If PersonTypeComboBox.SelectedItem = "ADMIN" Then
                PersonClientTextBox.Text = "901"
            ElseIf PersonTypeComboBox.SelectedItem = "EMPLOYEE" Then
                PersonClientTextBox.Text = "902"
            ElseIf PersonTypeComboBox.SelectedItem = "PATIENT" Then
                PersonClientTextBox.Text = "903"
            ElseIf PersonTypeComboBox.SelectedItem = "USER" Then
                PersonClientTextBox.Text = "903"
            End If
            '--------------User Information---------------------------------------------------
            Person_PreviewForm.Show()
            Dim answer As DialogResult
            answer = MessageBox.Show("Is all the information entered below correct?", "Yes/no sample", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If answer = vbYes Then
                Person_PreviewForm.Close()
                'enable confirm button
                SaveButton.Enabled = True
                SaveButton.Focus()
                AddButton.Enabled = False
                CancelButton.Enabled = True
                ExitButton.Enabled = True
                'enable confirm button
                PersonFNTextBox.ReadOnly = True
                PersonMiddleTextBox.ReadOnly = True
                PersonLNTextBox.ReadOnly = True
                PersonDOBDateTimePicker.Enabled = False
                PersonBranchIDComboBox.Enabled = False
                PersonGenderComboBox.Enabled = False
                PersonPhoneMaskedTextBox.Enabled = False
                PersonEmailTextBox.ReadOnly = True
                PersonPasswordTextBox.Enabled = False
                PersonTypeComboBox.Enabled = False

                'Enable/Disable User Address
                PersonStreetTextBox.ReadOnly = True
                PersonCityTextBox.ReadOnly = True
                PersonStreetTextBox.ReadOnly = True
                PersonZipMaskedTextBox.ReadOnly = True

                'Emergency Contact
                ContactFNTextBox.ReadOnly = True
                ContactLNTextBox.ReadOnly = True
                PhoneMaskedTextBox.ReadOnly = True

                'enable/disable user access info
                PersonClientTextBox.ReadOnly = True
                PersonClientTextBox.ReadOnly = True
                PersonIDTextBox.ReadOnly = True
                PasswordTextBox.ReadOnly = False
                CreateDateTimePicker.Enabled = False
                LastUpdatedByTextBox.ReadOnly = True
            End If
        End If

    End Sub
    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Dim result = MessageBox.Show("Are you sure you want to exit now? All unsaved changes will be lost immediately", "Are you sure?", MessageBoxButtons.YesNoCancel)
        If result = DialogResult.Yes Then
            PersonsForm.Show()
            Me.Close()
        End If
    End Sub
    Private Sub UserDataGridView_CellContentClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles PersonDataGridView.CellContentClick
        If e.RowIndex < 0 Or e.ColumnIndex < 0 Then
            Exit Sub
        End If

        PersonIDTextBox.Text = PersonDataGridView.Item(0, e.RowIndex).Value.ToString
        PersonClientTextBox.Text = PersonDataGridView.Item(1, e.RowIndex).Value.ToString
        PersonBranchIDComboBox.Text = PersonDataGridView.Item(2, e.RowIndex).Value.ToString
        PersonFNTextBox.Text = PersonDataGridView.Item(3, e.RowIndex).Value.ToString
        PersonMiddleTextBox.Text = PersonDataGridView.Item(4, e.RowIndex).Value.ToString
        PersonLNTextBox.Text = PersonDataGridView.Item(5, e.RowIndex).Value.ToString
        PersonGenderComboBox.Text = PersonDataGridView.Item(6, e.RowIndex).Value.ToString
        PersonPhoneMaskedTextBox.Text = PersonDataGridView.Item(7, e.RowIndex).Value.ToString
        PersonDOBDateTimePicker.Text = PersonDataGridView.Item(8, e.RowIndex).Value
        PersonAgeTextBox.Text = PersonDataGridView.Item(9, e.RowIndex).Value.ToString
        PersonTypeComboBox.Text = PersonDataGridView.Item(10, e.RowIndex).Value.ToString
        PersonPasswordTextBox.Text = PersonDataGridView.Item(11, e.RowIndex).Value.ToString
        PersonEmailTextBox.Text = PersonDataGridView.Item(12, e.RowIndex).Value.ToString
        PersonStreetTextBox.Text = PersonDataGridView.Item(13, e.RowIndex).Value.ToString
        PersonCityTextBox.Text = PersonDataGridView.Item(14, e.RowIndex).Value.ToString
        PersonZipMaskedTextBox.Text = PersonDataGridView.Item(15, e.RowIndex).Value.ToString
        PersonStateComboBox.Text = PersonDataGridView.Item(15, e.RowIndex).Value.ToString
        ContactFNTextBox.Text = PersonDataGridView.Item(16, e.RowIndex).Value.ToString
        ContactLNTextBox.Text = PersonDataGridView.Item(17, e.RowIndex).Value.ToString
        PhoneMaskedTextBox.Text = PersonDataGridView.Item(18, e.RowIndex).Value.ToString
        AddedByTextBox.Text = PersonDataGridView.Item(19, e.RowIndex).Value.ToString
        CreateDateTimePicker.Text = PersonDataGridView.Item(20, e.RowIndex).Value
        LastUpdatedByTextBox.Text = PersonDataGridView.Item(21, e.RowIndex).Value.ToString
        UpdateDateTimePicker.Value = PersonDataGridView.Item(22, e.RowIndex).Value.DBNUll

        CancelButton.Enabled = True
        AddButton.Enabled = False
        SaveButton.Enabled = False
        UpdateDateTimePicker.Value = Today

        'enabled/disabled
        PersonFNTextBox.ReadOnly = False
        PersonMiddleTextBox.ReadOnly = False
        PersonLNTextBox.ReadOnly = False
        PersonDOBDateTimePicker.Enabled = True
        PersonBranchIDComboBox.Enabled = True
        PersonGenderComboBox.Enabled = True
        PersonPhoneMaskedTextBox.ReadOnly = False
        PersonEmailTextBox.ReadOnly = False
        PersonPasswordTextBox.Enabled = True
        PersonTypeComboBox.Enabled = True
        'Enable/Disable User Address
        PersonStreetTextBox.ReadOnly = False
        PersonCityTextBox.ReadOnly = False
        PersonStreetTextBox.ReadOnly = False
        PersonZipMaskedTextBox.ReadOnly = False
        'Emergency Contact
        ContactFNTextBox.ReadOnly = False
        ContactLNTextBox.ReadOnly = False
        PhoneMaskedTextBox.Enabled = True
    End Sub

    Private Sub SaveButton_Click(sender As Object, e As EventArgs) Handles SaveButton.Click
        AddedByTextBox.Text = UserID
        AddPerson()
        PersonFNTextBox.Clear()
        PersonMiddleTextBox.Clear()
        PersonLNTextBox.Clear()
        PersonDOBDateTimePicker.CustomFormat = ""
        PersonAgeTextBox.Clear()
        PersonEmailTextBox.Clear()
        PersonBranchIDComboBox.ResetText()
        PersonGenderComboBox.SelectedIndex = -1
        PersonPhoneMaskedTextBox.Text = Today
        PersonTypeComboBox.SelectedIndex = -1
        PersonPasswordTextBox.Text = ""
        PersonStreetTextBox.Text = ""
        PersonCityTextBox.Clear()
        PersonStateComboBox.SelectedIndex = -1
        PersonZipMaskedTextBox.Clear()
        ContactFNTextBox.Clear()
        ContactLNTextBox.Clear()
        PhoneMaskedTextBox.Clear()
        PersonIDTextBox.Clear()
        PasswordTextBox.Clear()
        PersonClientTextBox.Clear()
    End Sub
    Private Sub AddPerson()
        If PersonFNTextBox.Text = "" Then
            MessageBox.Show("Please enter the person first name")
            PersonFNTextBox.Focus()
        ElseIf PersonPasswordTextBox.Text = "" Then
            MessageBox.Show("Please enter the persons password")
            PersonPasswordTextBox.Focus()
        Else

            'add parameters
            DB.AddParam("@PersonID", PersonIDTextBox.Text)
            DB.AddParam("@PersonClient", PersonClientTextBox.Text)
            DB.AddParam("@BranchID", PersonBranchIDComboBox.Text)
            DB.AddParam("@PersonFirstName", PersonFNTextBox.Text)
            DB.AddParam("@PersonMiddleInitialt", PersonMiddleTextBox.Text)
            DB.AddParam("@PersonLastName", PersonLNTextBox.Text)
            DB.AddParam("@PersonGender", PersonGenderComboBox.Text)
            DB.AddParam("@PersonPhoneNumber", PersonPhoneMaskedTextBox.Text)
            DB.AddParam("@PersonBirthDate", PersonDOBDateTimePicker.Value)
            DB.AddParam("@PersonAge", PersonAgeTextBox.Text)
            DB.AddParam("@PersonType", PersonTypeComboBox.Text)
            DB.AddParam("@PersonPassword", PersonPasswordTextBox.Text)
            DB.AddParam("@Personemail", PersonEmailTextBox.Text)
            'Add address parameters
            DB.AddParam("@PersonStreet", PersonStreetTextBox.Text)
            DB.AddParam("@PersonCity", PersonCityTextBox.Text)
            DB.AddParam("@PersonZip", PersonZipMaskedTextBox.Text)
            DB.AddParam("@PersonState", PersonStateComboBox.Text)
            'add contact emergency parameters
            DB.AddParam("@EmergencyFirstName", ContactFNTextBox.Text)
            DB.AddParam("@EmergencyLastName", ContactLNTextBox.Text)
            DB.AddParam("@EmergencyPhoneNumber", PhoneMaskedTextBox.Text)
            DB.AddParam("@AddedBy", AddedByTextBox.Text)
            DB.AddParam("@createdate", CreateDateTimePicker.Value)
            DB.ExecuteQuery("INSERT INTO person(PersonID, PersonClient, BranchID, PersonFirstName, PersonMiddleInitial, PersonLastName, PersonGender, PersonPhoneNumber, PersonBirthDate, PersonAge, PersonType, PersonPassword, PersonEmail, PersonStreet, PersonCity, PersonZip, PersonState, EmergencyFirstName, EmergencyLastName, EmergencyPhoneNumber, AddedBy, CreateDate)" &
"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")

            If DB.Exception <> String.Empty Then
                MessageBox.Show(DB.Exception)
                Exit Sub
            End If
            'success
            MessageBox.Show(String.Format("A new person bas been sucessfully recorded as: " & vbNewLine & "{0}", PersonIDTextBox.Text))
            'Refresh table
            PersonDataGridView.ReadOnly = True
            DB.ExecuteQuery("Select * from person")
            If DB.Exception <> String.Empty Then
                MessageBox.Show(DB.Exception)
                Exit Sub
            End If
            'Fill datagrid cell click
            PersonDataGridView.DataSource = DB.DBDataTable
            'enable datagrid cell click
            PersonDataGridView.Enabled = True

            'enable confirm button
            PersonFNTextBox.ReadOnly = True
            PersonMiddleTextBox.ReadOnly = True
            PersonLNTextBox.ReadOnly = True
            PersonDOBDateTimePicker.Enabled = False
            PersonBranchIDComboBox.Enabled = False
            PersonGenderComboBox.Enabled = False
            PersonPhoneMaskedTextBox.ReadOnly = True
            PersonEmailTextBox.ReadOnly = True
            PersonPasswordTextBox.Enabled = False
            PersonTypeComboBox.Enabled = False
            'Enable/Disable User Address
            PersonStreetTextBox.ReadOnly = True
            PersonCityTextBox.ReadOnly = True
            PersonStreetTextBox.ReadOnly = True
            PersonZipMaskedTextBox.ReadOnly = True
            'Emergency Contact
            ContactFNTextBox.ReadOnly = True
            ContactLNTextBox.ReadOnly = True
            PhoneMaskedTextBox.Enabled = False
            'enable/disable user access info
            PersonClientTextBox.ReadOnly = True
            PersonIDTextBox.ReadOnly = True
            PasswordTextBox.ReadOnly = True
            CreateDateTimePicker.Value = Today
            LastUpdatedByTextBox.ReadOnly = True

            AddButton.Enabled = True
            CancelButton.Enabled = True
            SaveButton.Enabled = False

            'Clear Text
            PersonFNTextBox.Clear()
            PersonMiddleTextBox.Clear()
            PersonLNTextBox.Clear()
            PersonDOBDateTimePicker.CustomFormat = ""
            PersonAgeTextBox.Clear()
            PersonBranchIDComboBox.Text = String.Empty
            PersonGenderComboBox.Text = String.Empty
            PersonPhoneMaskedTextBox.Text = String.Empty
            PersonTypeComboBox.Text = String.Empty
            PersonPasswordTextBox.Text = ""
            PersonStreetTextBox.Text = ""
            PersonCityTextBox.Clear()
            PersonStateComboBox.Text = String.Empty
            PersonZipMaskedTextBox.Text = String.Empty
            ContactFNTextBox.Clear()
            ContactLNTextBox.Clear()
            PhoneMaskedTextBox.Text = String.Empty
            PersonIDTextBox.Clear()
            PasswordTextBox.Clear()
            PersonClientTextBox.Clear()
            Exit Sub
        End If
    End Sub
    Private Sub PersonDOBDateTimePicker_ValueChanged(sender As Object, e As EventArgs) Handles PersonDOBDateTimePicker.ValueChanged
        With PersonDOBDateTimePicker.Value
            Dim celebrate As DateTime = New DateTime(Now.Year, .Month, .Day)
            Dim age As Integer = Now.Year - .Year
            If celebrate > Now Then age -= 1
            PersonAgeTextBox.Text = CStr(age)
        End With
    End Sub
End Class