﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class NewPersonForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(NewPersonForm))
        Me.PersonDataGridView = New System.Windows.Forms.DataGridView()
        Me.UserFNLabel = New System.Windows.Forms.Label()
        Me.CancelButton = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.SaveButton = New System.Windows.Forms.Button()
        Me.AddButton = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.PersonStateComboBox = New System.Windows.Forms.ComboBox()
        Me.PersonZipMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.PersonCityTextBox = New System.Windows.Forms.TextBox()
        Me.PersonStreetTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PersonAgeTextBox = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.PersonBranchIDComboBox = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.PersonDOBDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.PersonGenderComboBox = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.PersonTypeComboBox = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.PersonPasswordTextBox = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.PhoneLabel = New System.Windows.Forms.Label()
        Me.PersonPhoneMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.PersonEmailTextBox = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PersonMiddleTextBox = New System.Windows.Forms.TextBox()
        Me.PersonLNTextBox = New System.Windows.Forms.TextBox()
        Me.PersonFNTextBox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.UserGroupBox = New System.Windows.Forms.GroupBox()
        Me.UpdateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.LastUpdatedByTextBox = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.CreateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.AddedByTextBox = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PersonIDTextBox = New System.Windows.Forms.TextBox()
        Me.PasswordTextBox = New System.Windows.Forms.TextBox()
        Me.PersonIDLabel = New System.Windows.Forms.Label()
        Me.PassWordLabel = New System.Windows.Forms.Label()
        Me.PersonClientTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.PhoneMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.ContactFNTextBox = New System.Windows.Forms.TextBox()
        Me.ContactLNTextBox = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.UserIdLabel1 = New System.Windows.Forms.Label()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        CType(Me.PersonDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.UserGroupBox.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'PersonDataGridView
        '
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Book Antiqua", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonDataGridView.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.PersonDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Book Antiqua", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PersonDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.PersonDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.PersonDataGridView.GridColor = System.Drawing.SystemColors.ControlLightLight
        Me.PersonDataGridView.Location = New System.Drawing.Point(23, 8)
        Me.PersonDataGridView.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonDataGridView.Name = "PersonDataGridView"
        Me.PersonDataGridView.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PersonDataGridView.RowsDefaultCellStyle = DataGridViewCellStyle3
        Me.PersonDataGridView.RowTemplate.Height = 33
        Me.PersonDataGridView.Size = New System.Drawing.Size(1519, 398)
        Me.PersonDataGridView.TabIndex = 28
        '
        'UserFNLabel
        '
        Me.UserFNLabel.AutoSize = True
        Me.UserFNLabel.Location = New System.Drawing.Point(10, 25)
        Me.UserFNLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.UserFNLabel.Name = "UserFNLabel"
        Me.UserFNLabel.Size = New System.Drawing.Size(152, 32)
        Me.UserFNLabel.TabIndex = 1
        Me.UserFNLabel.Text = "First Name"
        '
        'CancelButton
        '
        Me.CancelButton.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.CancelButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CancelButton.ForeColor = System.Drawing.Color.Black
        Me.CancelButton.Location = New System.Drawing.Point(600, 973)
        Me.CancelButton.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.CancelButton.Name = "CancelButton"
        Me.CancelButton.Size = New System.Drawing.Size(188, 55)
        Me.CancelButton.TabIndex = 19
        Me.CancelButton.Text = "&Cancel"
        Me.CancelButton.UseVisualStyleBackColor = False
        '
        'ExitButton
        '
        Me.ExitButton.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ExitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ExitButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExitButton.ForeColor = System.Drawing.Color.Black
        Me.ExitButton.Location = New System.Drawing.Point(1107, 973)
        Me.ExitButton.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(188, 55)
        Me.ExitButton.TabIndex = 20
        Me.ExitButton.Text = "E&xit"
        Me.ExitButton.UseVisualStyleBackColor = False
        '
        'SaveButton
        '
        Me.SaveButton.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.SaveButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SaveButton.ForeColor = System.Drawing.Color.Black
        Me.SaveButton.Location = New System.Drawing.Point(861, 973)
        Me.SaveButton.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(188, 55)
        Me.SaveButton.TabIndex = 34
        Me.SaveButton.Text = "&Save"
        Me.SaveButton.UseVisualStyleBackColor = False
        '
        'AddButton
        '
        Me.AddButton.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.AddButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddButton.ForeColor = System.Drawing.Color.Black
        Me.AddButton.Location = New System.Drawing.Point(353, 973)
        Me.AddButton.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.AddButton.Name = "AddButton"
        Me.AddButton.Size = New System.Drawing.Size(188, 55)
        Me.AddButton.TabIndex = 18
        Me.AddButton.Text = "&Add"
        Me.AddButton.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.AutoSize = True
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.PersonStateComboBox)
        Me.GroupBox2.Controls.Add(Me.PersonZipMaskedTextBox)
        Me.GroupBox2.Controls.Add(Me.PersonCityTextBox)
        Me.GroupBox2.Controls.Add(Me.PersonStreetTextBox)
        Me.GroupBox2.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.GroupBox2.Location = New System.Drawing.Point(188, 773)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox2.Size = New System.Drawing.Size(444, 177)
        Me.GroupBox2.TabIndex = 31
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Person Address:"
        '
        'PersonStateComboBox
        '
        Me.PersonStateComboBox.AutoCompleteCustomSource.AddRange(New String() {"Male", "Female", "Other"})
        Me.PersonStateComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.PersonStateComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.PersonStateComboBox.BackColor = System.Drawing.Color.White
        Me.PersonStateComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.PersonStateComboBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonStateComboBox.Items.AddRange(New Object() {"AK", "AL", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"})
        Me.PersonStateComboBox.Location = New System.Drawing.Point(240, 96)
        Me.PersonStateComboBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PersonStateComboBox.MaxLength = 2
        Me.PersonStateComboBox.Name = "PersonStateComboBox"
        Me.PersonStateComboBox.Size = New System.Drawing.Size(77, 40)
        Me.PersonStateComboBox.TabIndex = 13
        '
        'PersonZipMaskedTextBox
        '
        Me.PersonZipMaskedTextBox.BackColor = System.Drawing.Color.White
        Me.PersonZipMaskedTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonZipMaskedTextBox.Location = New System.Drawing.Point(341, 96)
        Me.PersonZipMaskedTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PersonZipMaskedTextBox.Mask = "00000"
        Me.PersonZipMaskedTextBox.Name = "PersonZipMaskedTextBox"
        Me.PersonZipMaskedTextBox.Size = New System.Drawing.Size(94, 41)
        Me.PersonZipMaskedTextBox.TabIndex = 14
        '
        'PersonCityTextBox
        '
        Me.PersonCityTextBox.BackColor = System.Drawing.Color.White
        Me.PersonCityTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonCityTextBox.Location = New System.Drawing.Point(9, 96)
        Me.PersonCityTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonCityTextBox.Name = "PersonCityTextBox"
        Me.PersonCityTextBox.Size = New System.Drawing.Size(201, 41)
        Me.PersonCityTextBox.TabIndex = 12
        '
        'PersonStreetTextBox
        '
        Me.PersonStreetTextBox.BackColor = System.Drawing.Color.White
        Me.PersonStreetTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonStreetTextBox.Location = New System.Drawing.Point(9, 35)
        Me.PersonStreetTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonStreetTextBox.Name = "PersonStreetTextBox"
        Me.PersonStreetTextBox.Size = New System.Drawing.Size(426, 41)
        Me.PersonStreetTextBox.TabIndex = 11
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.PersonAgeTextBox)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.PersonBranchIDComboBox)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.PersonDOBDateTimePicker)
        Me.GroupBox1.Controls.Add(Me.PersonGenderComboBox)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.PersonTypeComboBox)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.PersonPasswordTextBox)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.PhoneLabel)
        Me.GroupBox1.Controls.Add(Me.PersonPhoneMaskedTextBox)
        Me.GroupBox1.Controls.Add(Me.PersonEmailTextBox)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.PersonMiddleTextBox)
        Me.GroupBox1.Controls.Add(Me.PersonLNTextBox)
        Me.GroupBox1.Controls.Add(Me.PersonFNTextBox)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.UserFNLabel)
        Me.GroupBox1.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox1.Location = New System.Drawing.Point(132, 422)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(848, 323)
        Me.GroupBox1.TabIndex = 30
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Person Information"
        '
        'PersonAgeTextBox
        '
        Me.PersonAgeTextBox.BackColor = System.Drawing.Color.White
        Me.PersonAgeTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonAgeTextBox.Location = New System.Drawing.Point(194, 208)
        Me.PersonAgeTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonAgeTextBox.MaxLength = 1
        Me.PersonAgeTextBox.Name = "PersonAgeTextBox"
        Me.PersonAgeTextBox.Size = New System.Drawing.Size(63, 41)
        Me.PersonAgeTextBox.TabIndex = 5
        Me.PersonAgeTextBox.TabStop = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(10, 213)
        Me.Label14.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 32)
        Me.Label14.TabIndex = 22
        Me.Label14.Text = "Age:"
        '
        'PersonBranchIDComboBox
        '
        Me.PersonBranchIDComboBox.AutoCompleteCustomSource.AddRange(New String() {"Male", "Female", "Other"})
        Me.PersonBranchIDComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.PersonBranchIDComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.PersonBranchIDComboBox.BackColor = System.Drawing.Color.White
        Me.PersonBranchIDComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.PersonBranchIDComboBox.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.PersonBranchIDComboBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonBranchIDComboBox.Items.AddRange(New Object() {"1", "2", "3"})
        Me.PersonBranchIDComboBox.Location = New System.Drawing.Point(598, 22)
        Me.PersonBranchIDComboBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PersonBranchIDComboBox.MaxLength = 2
        Me.PersonBranchIDComboBox.Name = "PersonBranchIDComboBox"
        Me.PersonBranchIDComboBox.Size = New System.Drawing.Size(101, 40)
        Me.PersonBranchIDComboBox.TabIndex = 6
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(422, 25)
        Me.Label13.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(151, 32)
        Me.Label13.TabIndex = 21
        Me.Label13.Text = "Branch ID:"
        '
        'PersonDOBDateTimePicker
        '
        Me.PersonDOBDateTimePicker.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonDOBDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.PersonDOBDateTimePicker.ImeMode = System.Windows.Forms.ImeMode.[On]
        Me.PersonDOBDateTimePicker.Location = New System.Drawing.Point(194, 161)
        Me.PersonDOBDateTimePicker.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PersonDOBDateTimePicker.Name = "PersonDOBDateTimePicker"
        Me.PersonDOBDateTimePicker.Size = New System.Drawing.Size(177, 41)
        Me.PersonDOBDateTimePicker.TabIndex = 4
        '
        'PersonGenderComboBox
        '
        Me.PersonGenderComboBox.AllowDrop = True
        Me.PersonGenderComboBox.AutoCompleteCustomSource.AddRange(New String() {"M", "F"})
        Me.PersonGenderComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.PersonGenderComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.PersonGenderComboBox.BackColor = System.Drawing.Color.White
        Me.PersonGenderComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.PersonGenderComboBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonGenderComboBox.FormattingEnabled = True
        Me.PersonGenderComboBox.Items.AddRange(New Object() {"M", "F", "O"})
        Me.PersonGenderComboBox.Location = New System.Drawing.Point(598, 68)
        Me.PersonGenderComboBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PersonGenderComboBox.Name = "PersonGenderComboBox"
        Me.PersonGenderComboBox.Size = New System.Drawing.Size(103, 40)
        Me.PersonGenderComboBox.TabIndex = 7
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(422, 71)
        Me.Label10.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(117, 32)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "Gender:"
        '
        'PersonTypeComboBox
        '
        Me.PersonTypeComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.PersonTypeComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.PersonTypeComboBox.BackColor = System.Drawing.Color.White
        Me.PersonTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.PersonTypeComboBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonTypeComboBox.ItemHeight = 32
        Me.PersonTypeComboBox.Items.AddRange(New Object() {"ADMIN", "PATIENT", "EMPLOYEE", "USER"})
        Me.PersonTypeComboBox.Location = New System.Drawing.Point(598, 166)
        Me.PersonTypeComboBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PersonTypeComboBox.Name = "PersonTypeComboBox"
        Me.PersonTypeComboBox.Size = New System.Drawing.Size(176, 40)
        Me.PersonTypeComboBox.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(422, 169)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(179, 32)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Person Type:"
        '
        'PersonPasswordTextBox
        '
        Me.PersonPasswordTextBox.BackColor = System.Drawing.Color.White
        Me.PersonPasswordTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonPasswordTextBox.Location = New System.Drawing.Point(598, 214)
        Me.PersonPasswordTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonPasswordTextBox.Name = "PersonPasswordTextBox"
        Me.PersonPasswordTextBox.Size = New System.Drawing.Size(176, 41)
        Me.PersonPasswordTextBox.TabIndex = 10
        Me.PersonPasswordTextBox.UseSystemPasswordChar = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(422, 217)
        Me.Label8.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(142, 32)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Password:"
        '
        'PhoneLabel
        '
        Me.PhoneLabel.AutoSize = True
        Me.PhoneLabel.Location = New System.Drawing.Point(422, 119)
        Me.PhoneLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.PhoneLabel.Name = "PhoneLabel"
        Me.PhoneLabel.Size = New System.Drawing.Size(125, 32)
        Me.PhoneLabel.TabIndex = 15
        Me.PhoneLabel.Text = "Phone #:"
        '
        'PersonPhoneMaskedTextBox
        '
        Me.PersonPhoneMaskedTextBox.BackColor = System.Drawing.Color.White
        Me.PersonPhoneMaskedTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonPhoneMaskedTextBox.Location = New System.Drawing.Point(598, 116)
        Me.PersonPhoneMaskedTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PersonPhoneMaskedTextBox.Mask = "(999) 000-0000"
        Me.PersonPhoneMaskedTextBox.Name = "PersonPhoneMaskedTextBox"
        Me.PersonPhoneMaskedTextBox.Size = New System.Drawing.Size(176, 41)
        Me.PersonPhoneMaskedTextBox.TabIndex = 8
        '
        'PersonEmailTextBox
        '
        Me.PersonEmailTextBox.BackColor = System.Drawing.Color.White
        Me.PersonEmailTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonEmailTextBox.Location = New System.Drawing.Point(194, 255)
        Me.PersonEmailTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonEmailTextBox.Name = "PersonEmailTextBox"
        Me.PersonEmailTextBox.Size = New System.Drawing.Size(396, 41)
        Me.PersonEmailTextBox.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(10, 260)
        Me.Label5.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(95, 32)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Email:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 166)
        Me.Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(91, 32)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "D.O.B"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(10, 119)
        Me.Label2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(155, 32)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Last Name:"
        '
        'PersonMiddleTextBox
        '
        Me.PersonMiddleTextBox.BackColor = System.Drawing.Color.White
        Me.PersonMiddleTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonMiddleTextBox.Location = New System.Drawing.Point(194, 66)
        Me.PersonMiddleTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonMiddleTextBox.MaxLength = 1
        Me.PersonMiddleTextBox.Name = "PersonMiddleTextBox"
        Me.PersonMiddleTextBox.Size = New System.Drawing.Size(63, 41)
        Me.PersonMiddleTextBox.TabIndex = 2
        '
        'PersonLNTextBox
        '
        Me.PersonLNTextBox.BackColor = System.Drawing.Color.White
        Me.PersonLNTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonLNTextBox.Location = New System.Drawing.Point(194, 114)
        Me.PersonLNTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonLNTextBox.MaxLength = 45
        Me.PersonLNTextBox.Name = "PersonLNTextBox"
        Me.PersonLNTextBox.Size = New System.Drawing.Size(174, 41)
        Me.PersonLNTextBox.TabIndex = 3
        '
        'PersonFNTextBox
        '
        Me.PersonFNTextBox.BackColor = System.Drawing.Color.White
        Me.PersonFNTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonFNTextBox.Location = New System.Drawing.Point(194, 20)
        Me.PersonFNTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonFNTextBox.MaxLength = 45
        Me.PersonFNTextBox.Name = "PersonFNTextBox"
        Me.PersonFNTextBox.Size = New System.Drawing.Size(174, 41)
        Me.PersonFNTextBox.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 72)
        Me.Label3.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(200, 32)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Middle Initial:"
        '
        'UserGroupBox
        '
        Me.UserGroupBox.BackColor = System.Drawing.Color.Transparent
        Me.UserGroupBox.Controls.Add(Me.UpdateDateTimePicker)
        Me.UserGroupBox.Controls.Add(Me.Label12)
        Me.UserGroupBox.Controls.Add(Me.LastUpdatedByTextBox)
        Me.UserGroupBox.Controls.Add(Me.Label11)
        Me.UserGroupBox.Controls.Add(Me.CreateDateTimePicker)
        Me.UserGroupBox.Controls.Add(Me.AddedByTextBox)
        Me.UserGroupBox.Controls.Add(Me.Label7)
        Me.UserGroupBox.Controls.Add(Me.Label6)
        Me.UserGroupBox.Controls.Add(Me.PersonIDTextBox)
        Me.UserGroupBox.Controls.Add(Me.PasswordTextBox)
        Me.UserGroupBox.Controls.Add(Me.PersonIDLabel)
        Me.UserGroupBox.Controls.Add(Me.PassWordLabel)
        Me.UserGroupBox.Controls.Add(Me.PersonClientTextBox)
        Me.UserGroupBox.Controls.Add(Me.Label1)
        Me.UserGroupBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserGroupBox.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.UserGroupBox.Location = New System.Drawing.Point(1146, 414)
        Me.UserGroupBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserGroupBox.Name = "UserGroupBox"
        Me.UserGroupBox.Padding = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserGroupBox.Size = New System.Drawing.Size(371, 338)
        Me.UserGroupBox.TabIndex = 29
        Me.UserGroupBox.TabStop = False
        Me.UserGroupBox.Text = "PERSON ACCESS INFO:"
        '
        'UpdateDateTimePicker
        '
        Me.UpdateDateTimePicker.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UpdateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.UpdateDateTimePicker.Location = New System.Drawing.Point(149, 292)
        Me.UpdateDateTimePicker.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.UpdateDateTimePicker.Name = "UpdateDateTimePicker"
        Me.UpdateDateTimePicker.Size = New System.Drawing.Size(174, 41)
        Me.UpdateDateTimePicker.TabIndex = 13
        Me.UpdateDateTimePicker.TabStop = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(10, 292)
        Me.Label12.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(124, 32)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "Updated"
        '
        'LastUpdatedByTextBox
        '
        Me.LastUpdatedByTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LastUpdatedByTextBox.Location = New System.Drawing.Point(149, 252)
        Me.LastUpdatedByTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.LastUpdatedByTextBox.Name = "LastUpdatedByTextBox"
        Me.LastUpdatedByTextBox.ReadOnly = True
        Me.LastUpdatedByTextBox.Size = New System.Drawing.Size(174, 41)
        Me.LastUpdatedByTextBox.TabIndex = 11
        Me.LastUpdatedByTextBox.TabStop = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(10, 248)
        Me.Label11.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(190, 32)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Last Updated:"
        '
        'CreateDateTimePicker
        '
        Me.CreateDateTimePicker.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CreateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.CreateDateTimePicker.Location = New System.Drawing.Point(149, 209)
        Me.CreateDateTimePicker.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.CreateDateTimePicker.Name = "CreateDateTimePicker"
        Me.CreateDateTimePicker.Size = New System.Drawing.Size(174, 41)
        Me.CreateDateTimePicker.TabIndex = 9
        Me.CreateDateTimePicker.TabStop = False
        '
        'AddedByTextBox
        '
        Me.AddedByTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.AddedByTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddedByTextBox.HideSelection = False
        Me.AddedByTextBox.Location = New System.Drawing.Point(149, 165)
        Me.AddedByTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.AddedByTextBox.MaxLength = 10
        Me.AddedByTextBox.Name = "AddedByTextBox"
        Me.AddedByTextBox.ReadOnly = True
        Me.AddedByTextBox.Size = New System.Drawing.Size(174, 41)
        Me.AddedByTextBox.TabIndex = 8
        Me.AddedByTextBox.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(10, 165)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(148, 32)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Added By:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(10, 209)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(147, 32)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Added on:"
        '
        'PersonIDTextBox
        '
        Me.PersonIDTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonIDTextBox.Location = New System.Drawing.Point(149, 74)
        Me.PersonIDTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonIDTextBox.MaxLength = 8
        Me.PersonIDTextBox.Name = "PersonIDTextBox"
        Me.PersonIDTextBox.ReadOnly = True
        Me.PersonIDTextBox.Size = New System.Drawing.Size(174, 41)
        Me.PersonIDTextBox.TabIndex = 5
        Me.PersonIDTextBox.TabStop = False
        '
        'PasswordTextBox
        '
        Me.PasswordTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PasswordTextBox.Location = New System.Drawing.Point(149, 121)
        Me.PasswordTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PasswordTextBox.MaxLength = 45
        Me.PasswordTextBox.Name = "PasswordTextBox"
        Me.PasswordTextBox.ReadOnly = True
        Me.PasswordTextBox.Size = New System.Drawing.Size(174, 41)
        Me.PasswordTextBox.TabIndex = 90
        Me.PasswordTextBox.TabStop = False
        '
        'PersonIDLabel
        '
        Me.PersonIDLabel.AutoSize = True
        Me.PersonIDLabel.Location = New System.Drawing.Point(10, 77)
        Me.PersonIDLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.PersonIDLabel.Name = "PersonIDLabel"
        Me.PersonIDLabel.Size = New System.Drawing.Size(148, 32)
        Me.PersonIDLabel.TabIndex = 3
        Me.PersonIDLabel.Text = "Person ID:"
        '
        'PassWordLabel
        '
        Me.PassWordLabel.AutoSize = True
        Me.PassWordLabel.Location = New System.Drawing.Point(10, 121)
        Me.PassWordLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.PassWordLabel.Name = "PassWordLabel"
        Me.PassWordLabel.Size = New System.Drawing.Size(142, 32)
        Me.PassWordLabel.TabIndex = 2
        Me.PassWordLabel.Text = "Password:"
        '
        'PersonClientTextBox
        '
        Me.PersonClientTextBox.AcceptsReturn = True
        Me.PersonClientTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonClientTextBox.Location = New System.Drawing.Point(149, 30)
        Me.PersonClientTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonClientTextBox.MaxLength = 3
        Me.PersonClientTextBox.Name = "PersonClientTextBox"
        Me.PersonClientTextBox.ReadOnly = True
        Me.PersonClientTextBox.Size = New System.Drawing.Size(85, 41)
        Me.PersonClientTextBox.TabIndex = 1
        Me.PersonClientTextBox.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 33)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 32)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Client:"
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox4.Controls.Add(Me.PhoneMaskedTextBox)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.ContactFNTextBox)
        Me.GroupBox4.Controls.Add(Me.ContactLNTextBox)
        Me.GroupBox4.Controls.Add(Me.Label22)
        Me.GroupBox4.Controls.Add(Me.Label23)
        Me.GroupBox4.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.GroupBox4.Location = New System.Drawing.Point(680, 773)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox4.Size = New System.Drawing.Size(781, 127)
        Me.GroupBox4.TabIndex = 38
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Emergency Contact Information:"
        '
        'PhoneMaskedTextBox
        '
        Me.PhoneMaskedTextBox.BackColor = System.Drawing.Color.White
        Me.PhoneMaskedTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PhoneMaskedTextBox.Location = New System.Drawing.Point(535, 71)
        Me.PhoneMaskedTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.PhoneMaskedTextBox.Mask = "(999) 000-0000"
        Me.PhoneMaskedTextBox.Name = "PhoneMaskedTextBox"
        Me.PhoneMaskedTextBox.Size = New System.Drawing.Size(219, 41)
        Me.PhoneMaskedTextBox.TabIndex = 17
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label18.Location = New System.Drawing.Point(537, 35)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(214, 32)
        Me.Label18.TabIndex = 17
        Me.Label18.Text = "Phone Number:"
        '
        'ContactFNTextBox
        '
        Me.ContactFNTextBox.BackColor = System.Drawing.Color.White
        Me.ContactFNTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContactFNTextBox.Location = New System.Drawing.Point(15, 71)
        Me.ContactFNTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ContactFNTextBox.Name = "ContactFNTextBox"
        Me.ContactFNTextBox.Size = New System.Drawing.Size(225, 41)
        Me.ContactFNTextBox.TabIndex = 15
        '
        'ContactLNTextBox
        '
        Me.ContactLNTextBox.BackColor = System.Drawing.Color.White
        Me.ContactLNTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContactLNTextBox.Location = New System.Drawing.Point(275, 71)
        Me.ContactLNTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ContactLNTextBox.Name = "ContactLNTextBox"
        Me.ContactLNTextBox.Size = New System.Drawing.Size(225, 41)
        Me.ContactLNTextBox.TabIndex = 16
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label22.Location = New System.Drawing.Point(48, 37)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(159, 32)
        Me.Label22.TabIndex = 10
        Me.Label22.Text = "First Name:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label23.Location = New System.Drawing.Point(310, 37)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(155, 32)
        Me.Label23.TabIndex = 11
        Me.Label23.Text = "Last Name:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(1320, 911)
        Me.Label15.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(0, 25)
        Me.Label15.TabIndex = 39
        '
        'UserIdLabel1
        '
        Me.UserIdLabel1.AutoSize = True
        Me.UserIdLabel1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.UserIdLabel1.Location = New System.Drawing.Point(1171, 942)
        Me.UserIdLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.UserIdLabel1.Name = "UserIdLabel1"
        Me.UserIdLabel1.Size = New System.Drawing.Size(0, 25)
        Me.UserIdLabel1.TabIndex = 40
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'NewPersonForm
        '
        Me.AcceptButton = Me.AddButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1556, 1060)
        Me.Controls.Add(Me.UserIdLabel1)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.PersonDataGridView)
        Me.Controls.Add(Me.CancelButton)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.SaveButton)
        Me.Controls.Add(Me.AddButton)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.UserGroupBox)
        Me.Name = "NewPersonForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Add A new person!"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.PersonDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.UserGroupBox.ResumeLayout(False)
        Me.UserGroupBox.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PersonDataGridView As DataGridView
    Friend WithEvents UserFNLabel As Label
    Friend WithEvents CancelButton As Button
    Friend WithEvents ExitButton As Button
    Friend WithEvents SaveButton As Button
    Friend WithEvents AddButton As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents PersonStateComboBox As ComboBox
    Friend WithEvents PersonZipMaskedTextBox As MaskedTextBox
    Friend WithEvents PersonCityTextBox As TextBox
    Friend WithEvents PersonStreetTextBox As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents PersonDOBDateTimePicker As DateTimePicker
    Friend WithEvents PersonGenderComboBox As ComboBox
    Friend WithEvents Label10 As Label
    Friend WithEvents PersonTypeComboBox As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents PersonPasswordTextBox As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents PhoneLabel As Label
    Friend WithEvents PersonPhoneMaskedTextBox As MaskedTextBox
    Friend WithEvents PersonEmailTextBox As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PersonMiddleTextBox As TextBox
    Friend WithEvents PersonLNTextBox As TextBox
    Friend WithEvents PersonFNTextBox As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents UserGroupBox As GroupBox
    Friend WithEvents UpdateDateTimePicker As DateTimePicker
    Friend WithEvents Label12 As Label
    Friend WithEvents LastUpdatedByTextBox As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents CreateDateTimePicker As DateTimePicker
    Friend WithEvents AddedByTextBox As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents PersonIDTextBox As TextBox
    Friend WithEvents PasswordTextBox As TextBox
    Friend WithEvents PersonIDLabel As Label
    Friend WithEvents PassWordLabel As Label
    Friend WithEvents PersonClientTextBox As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PersonBranchIDComboBox As ComboBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Label18 As Label
    Friend WithEvents ContactFNTextBox As TextBox
    Friend WithEvents ContactLNTextBox As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents PhoneMaskedTextBox As MaskedTextBox
    Friend WithEvents PersonAgeTextBox As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents UserIdLabel1 As Label
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
End Class
