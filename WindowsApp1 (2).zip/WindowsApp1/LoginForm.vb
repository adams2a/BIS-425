﻿Imports System.Data.Odbc
Public Class LoginForm
    Private DB As New DBAccess

    Private Sub LoginButton_Click(sender As Object, e As EventArgs) Handles LoginButton.Click

        If ClientComboBox.Text = String.Empty Then
            MessageBox.Show("Client cannot be left empty!")
        End If
        If UserIDTextBox.Text = String.Empty Then
            MessageBox.Show("User ID cannot be left empty!")
            UserIDTextBox.Select()
            Exit Sub

        Else
            If PWTextBox.Text = String.Empty Then
                MessageBox.Show("Password cannot be left empty!")
                PWTextBox.Select()
                Exit Sub

            Else
                DB.AddParam("@PersonClient", ClientComboBox.Text)
                DB.AddParam("@PersonID", UserIDTextBox.Text)
                DB.AddParam("@PersonPassword", PWTextBox.Text)
                DB.ExecuteQuery("Select * from person where PersonClient = ? and Personid = ? and Personpassword = ?")

                If DB.Exception <> String.Empty Then
                    MessageBox.Show(DB.Exception)
                    Exit Sub
                Else
                    If DB.RecordCount = 0 Then
                        MessageBox.Show("The user ID and password do not match.")
                        PWTextBox.Text = ""
                        Exit Sub
                    Else
                        MessageBox.Show(String.Format("Successful Login." & vbNewLine & "Welcome {0}.", UserIDTextBox.Text))
                        Dim obj As New HomeForm
                        UserID = UserIDTextBox.Text
                        obj.Show()
                        Me.Close()
                        'HomeForm.Show()
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub CancelButton_Click(sender As Object, e As EventArgs) Handles CancelButton.Click
        Me.Close()

    End Sub
    Private Sub LoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles ClientLabel.Click

    End Sub

    Private Sub ClearButton_Click(sender As Object, e As EventArgs) Handles ClearButton.Click
        ClientComboBox.Text = ""
        UserIDTextBox.Clear()
        PWTextBox.Clear()
        ClientComboBox.Focus()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub AboutUsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutUsToolStripMenuItem.Click
        AboutBox.ShowDialog()
    End Sub

    Private Sub UserIDLabel_Click(sender As Object, e As EventArgs) Handles UserIDLabel.Click

    End Sub

    Private Sub UserIDTextBox_TextChanged(sender As Object, e As EventArgs) Handles UserIDTextBox.TextChanged

    End Sub

    Private Sub PWTextBox_TextChanged(sender As Object, e As EventArgs) Handles PWTextBox.TextChanged

    End Sub

    Private Sub ClientComboBox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ClientComboBox.SelectedIndexChanged
        Me.Focus()
    End Sub
End Class
