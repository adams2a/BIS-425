﻿Public Class HomeForm
    Public Property StringPass As String

    Private Sub HomeForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        UserIDLabel1.Text = UserID
        If LoginForm.ClientComboBox.SelectedItem = "901" Then
            PatientsButton.Enabled = True
            EmployeeButton.Enabled = True
            UsersButton.Enabled = True
            ReportButton.Enabled = True
        ElseIf LoginForm.ClientComboBox.SelectedItem = "902" Then
            PatientsButton.Enabled = False
            EmployeeButton.Enabled = False
            UsersButton.Enabled = True
            ReportButton.Enabled = True
            PersonsButton.Enabled = False
        ElseIf LoginForm.ClientComboBox.SelectedItem = "903" Then
            PatientsButton.Enabled = False
            EmployeeButton.Enabled = False
            UsersButton.Enabled = False
            ReportButton.Enabled = True
        End If
    End Sub
    Private Sub PatientsButton_Click(sender As System.Object, e As System.EventArgs) Handles PatientsButton.Click


        Dim obj As New Passwordform
        StringPass = UserIDLabel1.Text
        Passwordform.ShowDialog()
        Me.Hide()

    End Sub
    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Dim result = MessageBox.Show("Are you sure you want to quit", "Are you sure?", MessageBoxButtons.YesNoCancel)
        If result = DialogResult.Yes Then
            Me.Close()
        End If
    End Sub
    Private Sub EmployeesButton_Click(sender As Object, e As EventArgs)
        Dim obj As New EmployeesForm
        StringPass = UserIDLabel.Text
        obj.Show()
    End Sub
    Private Sub ReportButton_Click(sender As Object, e As EventArgs) Handles ReportButton.Click
        Dim obj As New ReportsForm
        StringPass = UserIDLabel.Text
        obj.Show()
    End Sub

    Private Sub personButton_Click(sender As Object, e As EventArgs) Handles PersonsButton.Click
        Dim obj As New PersonsForm
        StringPass = UserIDLabel.Text
        obj.Show()
    End Sub

    Private Sub EmployeeButton_Click(sender As Object, e As EventArgs) Handles EmployeeButton.Click
        Dim obj As New EmployeesForm
        obj.Show()
        Me.Close()
        'EmployeeForm.Show()
    End Sub

    Private Sub UsersButton_Click(sender As System.Object, e As System.EventArgs) Handles UsersButton.Click
        Dim obj As New ManageUsers
        StringPass = UserIDLabel.Text
        obj.Show()
        Me.Hide()
        'ManageUsers.Show()


    End Sub

End Class