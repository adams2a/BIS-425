﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class HomeForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(HomeForm))
        Me.UserIDLabel = New System.Windows.Forms.Label()
        Me.UsersButton = New System.Windows.Forms.Button()
        Me.PersonsButton = New System.Windows.Forms.Button()
        Me.EmployeeButton = New System.Windows.Forms.Button()
        Me.ReportButton = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.PatientsButton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.UserIDLabel1 = New System.Windows.Forms.Label()
        Me.NameLabel = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'UserIDLabel
        '
        Me.UserIDLabel.AutoSize = True
        Me.UserIDLabel.Location = New System.Drawing.Point(497, 83)
        Me.UserIDLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.UserIDLabel.Name = "UserIDLabel"
        Me.UserIDLabel.Size = New System.Drawing.Size(0, 32)
        Me.UserIDLabel.TabIndex = 0
        '
        'UsersButton
        '
        Me.UsersButton.BackColor = System.Drawing.SystemColors.Window
        Me.UsersButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UsersButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.UsersButton.Location = New System.Drawing.Point(291, 519)
        Me.UsersButton.Margin = New System.Windows.Forms.Padding(4)
        Me.UsersButton.Name = "UsersButton"
        Me.UsersButton.Size = New System.Drawing.Size(206, 53)
        Me.UsersButton.TabIndex = 5
        Me.UsersButton.Text = "&USERS"
        Me.UsersButton.UseVisualStyleBackColor = False
        '
        'PersonsButton
        '
        Me.PersonsButton.BackColor = System.Drawing.SystemColors.Window
        Me.PersonsButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonsButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.PersonsButton.Location = New System.Drawing.Point(62, 519)
        Me.PersonsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PersonsButton.Name = "PersonsButton"
        Me.PersonsButton.Size = New System.Drawing.Size(206, 53)
        Me.PersonsButton.TabIndex = 4
        Me.PersonsButton.Text = "&PERSON"
        Me.PersonsButton.UseVisualStyleBackColor = False
        '
        'EmployeeButton
        '
        Me.EmployeeButton.BackColor = System.Drawing.SystemColors.Window
        Me.EmployeeButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmployeeButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.EmployeeButton.Location = New System.Drawing.Point(291, 451)
        Me.EmployeeButton.Margin = New System.Windows.Forms.Padding(4)
        Me.EmployeeButton.Name = "EmployeeButton"
        Me.EmployeeButton.Size = New System.Drawing.Size(206, 53)
        Me.EmployeeButton.TabIndex = 3
        Me.EmployeeButton.Text = "&EMPLOYEES"
        Me.EmployeeButton.UseVisualStyleBackColor = False
        '
        'ReportButton
        '
        Me.ReportButton.BackColor = System.Drawing.SystemColors.Window
        Me.ReportButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReportButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ReportButton.Location = New System.Drawing.Point(62, 587)
        Me.ReportButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ReportButton.Name = "ReportButton"
        Me.ReportButton.Size = New System.Drawing.Size(206, 53)
        Me.ReportButton.TabIndex = 2
        Me.ReportButton.Text = "&REPORTS"
        Me.ReportButton.UseVisualStyleBackColor = False
        '
        'ExitButton
        '
        Me.ExitButton.BackColor = System.Drawing.SystemColors.Window
        Me.ExitButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExitButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ExitButton.Location = New System.Drawing.Point(291, 587)
        Me.ExitButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(206, 53)
        Me.ExitButton.TabIndex = 1
        Me.ExitButton.Text = "E&XIT"
        Me.ExitButton.UseVisualStyleBackColor = False
        '
        'PatientsButton
        '
        Me.PatientsButton.BackColor = System.Drawing.SystemColors.Window
        Me.PatientsButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PatientsButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.PatientsButton.Location = New System.Drawing.Point(62, 451)
        Me.PatientsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PatientsButton.Name = "PatientsButton"
        Me.PatientsButton.Size = New System.Drawing.Size(206, 53)
        Me.PatientsButton.TabIndex = 0
        Me.PatientsButton.Text = "&PATIENTS"
        Me.PatientsButton.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(220, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 32)
        Me.Label1.TabIndex = 6
        '
        'UserIDLabel1
        '
        Me.UserIDLabel1.AutoSize = True
        Me.UserIDLabel1.BackColor = System.Drawing.Color.Transparent
        Me.UserIDLabel1.Font = New System.Drawing.Font("Book Antiqua", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserIDLabel1.ForeColor = System.Drawing.Color.White
        Me.UserIDLabel1.Location = New System.Drawing.Point(220, 131)
        Me.UserIDLabel1.Name = "UserIDLabel1"
        Me.UserIDLabel1.Size = New System.Drawing.Size(0, 46)
        Me.UserIDLabel1.TabIndex = 7
        '
        'NameLabel
        '
        Me.NameLabel.BackColor = System.Drawing.Color.Transparent
        Me.NameLabel.Font = New System.Drawing.Font("Book Antiqua", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NameLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.NameLabel.Location = New System.Drawing.Point(58, 18)
        Me.NameLabel.Name = "NameLabel"
        Me.NameLabel.Size = New System.Drawing.Size(449, 77)
        Me.NameLabel.TabIndex = 8
        Me.NameLabel.Text = "Abundant Life Homes"
        Me.NameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Book Antiqua", 13.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(144, 88)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(272, 43)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Welcom user:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'HomeForm
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(558, 663)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.NameLabel)
        Me.Controls.Add(Me.UserIDLabel1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.UsersButton)
        Me.Controls.Add(Me.EmployeeButton)
        Me.Controls.Add(Me.PersonsButton)
        Me.Controls.Add(Me.ReportButton)
        Me.Controls.Add(Me.UserIDLabel)
        Me.Controls.Add(Me.PatientsButton)
        Me.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "HomeForm"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ABUNDANT LIFE HOMES"
        Me.TransparencyKey = System.Drawing.SystemColors.Control
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents UserIDLabel As Label
    Friend WithEvents EmployeeButton As Button
    Friend WithEvents ReportButton As Button
    Friend WithEvents ExitButton As Button
    Friend WithEvents PatientsButton As Button
    Friend WithEvents UsersButton As Button
    Friend WithEvents PersonsButton As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents UserIDLabel1 As Label
    Friend WithEvents NameLabel As Label
    Friend WithEvents Label2 As Label
End Class
