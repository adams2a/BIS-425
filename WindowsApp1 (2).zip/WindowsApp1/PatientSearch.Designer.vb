﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PatientSearch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SearchPatientIDTextBox = New System.Windows.Forms.TextBox()
        Me.PatientIDTextBox = New System.Windows.Forms.TextBox()
        Me.PatientDataGridView = New System.Windows.Forms.DataGridView()
        Me.Label = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PatientComboBox = New System.Windows.Forms.ComboBox()
        Me.SearchButton = New System.Windows.Forms.Button()
        Me.PatientNameTextBox = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.AddPatientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeletePatientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.PatientDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'SearchPatientIDTextBox
        '
        Me.SearchPatientIDTextBox.Location = New System.Drawing.Point(26, 113)
        Me.SearchPatientIDTextBox.Name = "SearchPatientIDTextBox"
        Me.SearchPatientIDTextBox.Size = New System.Drawing.Size(209, 31)
        Me.SearchPatientIDTextBox.TabIndex = 0
        '
        'PatientIDTextBox
        '
        Me.PatientIDTextBox.Location = New System.Drawing.Point(523, 86)
        Me.PatientIDTextBox.Name = "PatientIDTextBox"
        Me.PatientIDTextBox.ReadOnly = True
        Me.PatientIDTextBox.Size = New System.Drawing.Size(193, 31)
        Me.PatientIDTextBox.TabIndex = 2
        '
        'PatientDataGridView
        '
        Me.PatientDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.PatientDataGridView.Location = New System.Drawing.Point(12, 164)
        Me.PatientDataGridView.Name = "PatientDataGridView"
        Me.PatientDataGridView.RowTemplate.Height = 33
        Me.PatientDataGridView.Size = New System.Drawing.Size(1056, 487)
        Me.PatientDataGridView.TabIndex = 3
        '
        'Label
        '
        Me.Label.AutoSize = True
        Me.Label.Location = New System.Drawing.Point(31, 46)
        Me.Label.Name = "Label"
        Me.Label.Size = New System.Drawing.Size(111, 25)
        Me.Label.TabIndex = 4
        Me.Label.Text = "Patient ID:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(722, 89)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(147, 25)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Patient Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(406, 92)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(111, 25)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Patient ID:"
        '
        'PatientComboBox
        '
        Me.PatientComboBox.FormattingEnabled = True
        Me.PatientComboBox.Location = New System.Drawing.Point(26, 74)
        Me.PatientComboBox.Name = "PatientComboBox"
        Me.PatientComboBox.Size = New System.Drawing.Size(338, 33)
        Me.PatientComboBox.TabIndex = 7
        '
        'SearchButton
        '
        Me.SearchButton.Location = New System.Drawing.Point(252, 113)
        Me.SearchButton.Name = "SearchButton"
        Me.SearchButton.Size = New System.Drawing.Size(112, 42)
        Me.SearchButton.TabIndex = 8
        Me.SearchButton.Text = "&Search"
        Me.SearchButton.UseVisualStyleBackColor = True
        '
        'PatientNameTextBox
        '
        Me.PatientNameTextBox.Location = New System.Drawing.Point(875, 86)
        Me.PatientNameTextBox.Name = "PatientNameTextBox"
        Me.PatientNameTextBox.Size = New System.Drawing.Size(193, 31)
        Me.PatientNameTextBox.TabIndex = 1
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddPatientToolStripMenuItem, Me.DeletePatientToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1080, 40)
        Me.MenuStrip1.TabIndex = 9
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'AddPatientToolStripMenuItem
        '
        Me.AddPatientToolStripMenuItem.Name = "AddPatientToolStripMenuItem"
        Me.AddPatientToolStripMenuItem.Size = New System.Drawing.Size(150, 36)
        Me.AddPatientToolStripMenuItem.Text = "&Add &Patient"
        '
        'DeletePatientToolStripMenuItem
        '
        Me.DeletePatientToolStripMenuItem.Name = "DeletePatientToolStripMenuItem"
        Me.DeletePatientToolStripMenuItem.Size = New System.Drawing.Size(177, 36)
        Me.DeletePatientToolStripMenuItem.Text = "&Delete &Patient"
        '
        'PatientSearch
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(1080, 663)
        Me.Controls.Add(Me.SearchButton)
        Me.Controls.Add(Me.PatientComboBox)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label)
        Me.Controls.Add(Me.PatientDataGridView)
        Me.Controls.Add(Me.PatientIDTextBox)
        Me.Controls.Add(Me.PatientNameTextBox)
        Me.Controls.Add(Me.SearchPatientIDTextBox)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "PatientSearch"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PatientSearch"
        CType(Me.PatientDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents SearchPatientIDTextBox As TextBox
    Friend WithEvents PatientIDTextBox As TextBox
    Friend WithEvents PatientDataGridView As DataGridView
    Friend WithEvents Label As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PatientComboBox As ComboBox
    Friend WithEvents SearchButton As Button
    Friend WithEvents PatientNameTextBox As TextBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents AddPatientToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeletePatientToolStripMenuItem As ToolStripMenuItem
End Class
