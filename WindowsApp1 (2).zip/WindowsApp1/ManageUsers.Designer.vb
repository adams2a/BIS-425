﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ManageUsers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ManageUsers))
        Me.CancelButton = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.UpdateButton = New System.Windows.Forms.Button()
        Me.ConfirmButton = New System.Windows.Forms.Button()
        Me.AddButton = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.UserStateComboBox = New System.Windows.Forms.ComboBox()
        Me.UserZipMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.UserCityTextBox = New System.Windows.Forms.TextBox()
        Me.UserStreetTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.UserDOBDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.UserGenderComboBox = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.UserTypeComboBox = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.UserPasswordTextBox = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.PhoneLabel = New System.Windows.Forms.Label()
        Me.UserPhoneMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.UserEmailTextBox = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.UserMiddleTextBox = New System.Windows.Forms.TextBox()
        Me.UserLNTextBox = New System.Windows.Forms.TextBox()
        Me.UserFNTextBox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.UserFNLabel = New System.Windows.Forms.Label()
        Me.UserGroupBox = New System.Windows.Forms.GroupBox()
        Me.UpdateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.LastUpdatedByTextBox = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.CreateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.AddedByTextBox = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.UserIDTextBox = New System.Windows.Forms.TextBox()
        Me.PasswordTextBox = New System.Windows.Forms.TextBox()
        Me.UserIDLabel = New System.Windows.Forms.Label()
        Me.PassWordLabel = New System.Windows.Forms.Label()
        Me.UserClientTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.UserDataGridView = New System.Windows.Forms.DataGridView()
        Me.UserIDLabel2 = New System.Windows.Forms.Label()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.UserGroupBox.SuspendLayout()
        CType(Me.UserDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CancelButton
        '
        Me.CancelButton.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.CancelButton.ForeColor = System.Drawing.Color.Black
        Me.CancelButton.Location = New System.Drawing.Point(13, 593)
        Me.CancelButton.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.CancelButton.Name = "CancelButton"
        Me.CancelButton.Size = New System.Drawing.Size(188, 55)
        Me.CancelButton.TabIndex = 27
        Me.CancelButton.Text = "&Cancel"
        Me.CancelButton.UseVisualStyleBackColor = False
        '
        'ExitButton
        '
        Me.ExitButton.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ExitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ExitButton.ForeColor = System.Drawing.Color.Black
        Me.ExitButton.Location = New System.Drawing.Point(839, 593)
        Me.ExitButton.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(188, 55)
        Me.ExitButton.TabIndex = 26
        Me.ExitButton.Text = "E&xit"
        Me.ExitButton.UseVisualStyleBackColor = False
        '
        'UpdateButton
        '
        Me.UpdateButton.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.UpdateButton.ForeColor = System.Drawing.Color.Black
        Me.UpdateButton.Location = New System.Drawing.Point(221, 593)
        Me.UpdateButton.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.UpdateButton.Name = "UpdateButton"
        Me.UpdateButton.Size = New System.Drawing.Size(188, 55)
        Me.UpdateButton.TabIndex = 25
        Me.UpdateButton.Text = "&Update"
        Me.UpdateButton.UseVisualStyleBackColor = False
        '
        'ConfirmButton
        '
        Me.ConfirmButton.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ConfirmButton.ForeColor = System.Drawing.Color.Black
        Me.ConfirmButton.Location = New System.Drawing.Point(633, 593)
        Me.ConfirmButton.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ConfirmButton.Name = "ConfirmButton"
        Me.ConfirmButton.Size = New System.Drawing.Size(188, 55)
        Me.ConfirmButton.TabIndex = 24
        Me.ConfirmButton.Text = "&Confirm"
        Me.ConfirmButton.UseVisualStyleBackColor = False
        '
        'AddButton
        '
        Me.AddButton.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.AddButton.ForeColor = System.Drawing.Color.Black
        Me.AddButton.Location = New System.Drawing.Point(427, 593)
        Me.AddButton.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.AddButton.Name = "AddButton"
        Me.AddButton.Size = New System.Drawing.Size(188, 55)
        Me.AddButton.TabIndex = 23
        Me.AddButton.Text = "&Add"
        Me.AddButton.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.UserStateComboBox)
        Me.GroupBox2.Controls.Add(Me.UserZipMaskedTextBox)
        Me.GroupBox2.Controls.Add(Me.UserCityTextBox)
        Me.GroupBox2.Controls.Add(Me.UserStreetTextBox)
        Me.GroupBox2.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.GroupBox2.Location = New System.Drawing.Point(4, 465)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox2.Size = New System.Drawing.Size(444, 115)
        Me.GroupBox2.TabIndex = 22
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "User Address:"
        '
        'UserStateComboBox
        '
        Me.UserStateComboBox.AutoCompleteCustomSource.AddRange(New String() {"Male", "Female", "Other"})
        Me.UserStateComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.UserStateComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.UserStateComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.UserStateComboBox.Items.AddRange(New Object() {"AK", "AL", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"})
        Me.UserStateComboBox.Location = New System.Drawing.Point(148, 78)
        Me.UserStateComboBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.UserStateComboBox.MaxLength = 2
        Me.UserStateComboBox.Name = "UserStateComboBox"
        Me.UserStateComboBox.Size = New System.Drawing.Size(77, 40)
        Me.UserStateComboBox.TabIndex = 12
        '
        'UserZipMaskedTextBox
        '
        Me.UserZipMaskedTextBox.Location = New System.Drawing.Point(233, 78)
        Me.UserZipMaskedTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.UserZipMaskedTextBox.Mask = "00000"
        Me.UserZipMaskedTextBox.Name = "UserZipMaskedTextBox"
        Me.UserZipMaskedTextBox.Size = New System.Drawing.Size(94, 40)
        Me.UserZipMaskedTextBox.TabIndex = 18
        '
        'UserCityTextBox
        '
        Me.UserCityTextBox.Location = New System.Drawing.Point(9, 78)
        Me.UserCityTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserCityTextBox.Name = "UserCityTextBox"
        Me.UserCityTextBox.Size = New System.Drawing.Size(130, 40)
        Me.UserCityTextBox.TabIndex = 11
        '
        'UserStreetTextBox
        '
        Me.UserStreetTextBox.Location = New System.Drawing.Point(9, 35)
        Me.UserStreetTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserStreetTextBox.Name = "UserStreetTextBox"
        Me.UserStreetTextBox.Size = New System.Drawing.Size(426, 40)
        Me.UserStreetTextBox.TabIndex = 10
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.UserDOBDateTimePicker)
        Me.GroupBox1.Controls.Add(Me.UserGenderComboBox)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.UserTypeComboBox)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.UserPasswordTextBox)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.PhoneLabel)
        Me.GroupBox1.Controls.Add(Me.UserPhoneMaskedTextBox)
        Me.GroupBox1.Controls.Add(Me.UserEmailTextBox)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.UserMiddleTextBox)
        Me.GroupBox1.Controls.Add(Me.UserLNTextBox)
        Me.GroupBox1.Controls.Add(Me.UserFNTextBox)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.UserFNLabel)
        Me.GroupBox1.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.GroupBox1.Location = New System.Drawing.Point(13, 227)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(688, 232)
        Me.GroupBox1.TabIndex = 21
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "User Information"
        '
        'UserDOBDateTimePicker
        '
        Me.UserDOBDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.UserDOBDateTimePicker.ImeMode = System.Windows.Forms.ImeMode.[On]
        Me.UserDOBDateTimePicker.Location = New System.Drawing.Point(192, 146)
        Me.UserDOBDateTimePicker.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.UserDOBDateTimePicker.Name = "UserDOBDateTimePicker"
        Me.UserDOBDateTimePicker.Size = New System.Drawing.Size(177, 40)
        Me.UserDOBDateTimePicker.TabIndex = 4
        '
        'UserGenderComboBox
        '
        Me.UserGenderComboBox.AllowDrop = True
        Me.UserGenderComboBox.AutoCompleteCustomSource.AddRange(New String() {"Male", "Female", "Other"})
        Me.UserGenderComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.UserGenderComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.UserGenderComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.UserGenderComboBox.FormattingEnabled = True
        Me.UserGenderComboBox.Items.AddRange(New Object() {"Male", "Female", "Other"})
        Me.UserGenderComboBox.Location = New System.Drawing.Point(506, 20)
        Me.UserGenderComboBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.UserGenderComboBox.Name = "UserGenderComboBox"
        Me.UserGenderComboBox.Size = New System.Drawing.Size(103, 40)
        Me.UserGenderComboBox.TabIndex = 5
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(378, 25)
        Me.Label10.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(117, 32)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "Gender:"
        '
        'UserTypeComboBox
        '
        Me.UserTypeComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.UserTypeComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.UserTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.UserTypeComboBox.ItemHeight = 32
        Me.UserTypeComboBox.Items.AddRange(New Object() {"ADMIN", "PATIENT", "EMPLOYEE", "USER"})
        Me.UserTypeComboBox.Location = New System.Drawing.Point(506, 147)
        Me.UserTypeComboBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.UserTypeComboBox.Name = "UserTypeComboBox"
        Me.UserTypeComboBox.Size = New System.Drawing.Size(176, 40)
        Me.UserTypeComboBox.TabIndex = 8
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(378, 155)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(151, 32)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "User Type:"
        '
        'UserPasswordTextBox
        '
        Me.UserPasswordTextBox.Location = New System.Drawing.Point(506, 106)
        Me.UserPasswordTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserPasswordTextBox.Name = "UserPasswordTextBox"
        Me.UserPasswordTextBox.Size = New System.Drawing.Size(176, 40)
        Me.UserPasswordTextBox.TabIndex = 7
        Me.UserPasswordTextBox.UseSystemPasswordChar = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(378, 113)
        Me.Label8.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(142, 32)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Password:"
        '
        'PhoneLabel
        '
        Me.PhoneLabel.AutoSize = True
        Me.PhoneLabel.Location = New System.Drawing.Point(378, 69)
        Me.PhoneLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.PhoneLabel.Name = "PhoneLabel"
        Me.PhoneLabel.Size = New System.Drawing.Size(125, 32)
        Me.PhoneLabel.TabIndex = 15
        Me.PhoneLabel.Text = "Phone #:"
        '
        'UserPhoneMaskedTextBox
        '
        Me.UserPhoneMaskedTextBox.Location = New System.Drawing.Point(506, 64)
        Me.UserPhoneMaskedTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.UserPhoneMaskedTextBox.Mask = "000-000-0000"
        Me.UserPhoneMaskedTextBox.Name = "UserPhoneMaskedTextBox"
        Me.UserPhoneMaskedTextBox.Size = New System.Drawing.Size(176, 40)
        Me.UserPhoneMaskedTextBox.TabIndex = 6
        '
        'UserEmailTextBox
        '
        Me.UserEmailTextBox.Location = New System.Drawing.Point(192, 188)
        Me.UserEmailTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserEmailTextBox.Name = "UserEmailTextBox"
        Me.UserEmailTextBox.Size = New System.Drawing.Size(490, 40)
        Me.UserEmailTextBox.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(10, 191)
        Me.Label5.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(95, 32)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Email:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 150)
        Me.Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(91, 32)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "D.O.B"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(10, 109)
        Me.Label2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(155, 32)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Last Name:"
        '
        'UserMiddleTextBox
        '
        Me.UserMiddleTextBox.Location = New System.Drawing.Point(194, 64)
        Me.UserMiddleTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserMiddleTextBox.MaxLength = 1
        Me.UserMiddleTextBox.Name = "UserMiddleTextBox"
        Me.UserMiddleTextBox.Size = New System.Drawing.Size(63, 40)
        Me.UserMiddleTextBox.TabIndex = 2
        '
        'UserLNTextBox
        '
        Me.UserLNTextBox.Location = New System.Drawing.Point(194, 106)
        Me.UserLNTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserLNTextBox.MaxLength = 45
        Me.UserLNTextBox.Name = "UserLNTextBox"
        Me.UserLNTextBox.Size = New System.Drawing.Size(174, 40)
        Me.UserLNTextBox.TabIndex = 3
        '
        'UserFNTextBox
        '
        Me.UserFNTextBox.Location = New System.Drawing.Point(194, 20)
        Me.UserFNTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserFNTextBox.MaxLength = 45
        Me.UserFNTextBox.Name = "UserFNTextBox"
        Me.UserFNTextBox.Size = New System.Drawing.Size(174, 40)
        Me.UserFNTextBox.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 68)
        Me.Label3.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(200, 32)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Middle Initial:"
        '
        'UserFNLabel
        '
        Me.UserFNLabel.AutoSize = True
        Me.UserFNLabel.Location = New System.Drawing.Point(10, 25)
        Me.UserFNLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.UserFNLabel.Name = "UserFNLabel"
        Me.UserFNLabel.Size = New System.Drawing.Size(152, 32)
        Me.UserFNLabel.TabIndex = 1
        Me.UserFNLabel.Text = "First Name"
        '
        'UserGroupBox
        '
        Me.UserGroupBox.BackColor = System.Drawing.Color.Transparent
        Me.UserGroupBox.Controls.Add(Me.UpdateDateTimePicker)
        Me.UserGroupBox.Controls.Add(Me.Label12)
        Me.UserGroupBox.Controls.Add(Me.LastUpdatedByTextBox)
        Me.UserGroupBox.Controls.Add(Me.Label11)
        Me.UserGroupBox.Controls.Add(Me.CreateDateTimePicker)
        Me.UserGroupBox.Controls.Add(Me.AddedByTextBox)
        Me.UserGroupBox.Controls.Add(Me.Label7)
        Me.UserGroupBox.Controls.Add(Me.Label6)
        Me.UserGroupBox.Controls.Add(Me.UserIDTextBox)
        Me.UserGroupBox.Controls.Add(Me.PasswordTextBox)
        Me.UserGroupBox.Controls.Add(Me.UserIDLabel)
        Me.UserGroupBox.Controls.Add(Me.PassWordLabel)
        Me.UserGroupBox.Controls.Add(Me.UserClientTextBox)
        Me.UserGroupBox.Controls.Add(Me.Label1)
        Me.UserGroupBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserGroupBox.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.UserGroupBox.Location = New System.Drawing.Point(704, 238)
        Me.UserGroupBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserGroupBox.Name = "UserGroupBox"
        Me.UserGroupBox.Padding = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserGroupBox.Size = New System.Drawing.Size(371, 348)
        Me.UserGroupBox.TabIndex = 20
        Me.UserGroupBox.TabStop = False
        Me.UserGroupBox.Text = "USERS ACCESS INFO:"
        '
        'UpdateDateTimePicker
        '
        Me.UpdateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.UpdateDateTimePicker.Location = New System.Drawing.Point(149, 292)
        Me.UpdateDateTimePicker.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.UpdateDateTimePicker.Name = "UpdateDateTimePicker"
        Me.UpdateDateTimePicker.Size = New System.Drawing.Size(174, 40)
        Me.UpdateDateTimePicker.TabIndex = 13
        Me.UpdateDateTimePicker.TabStop = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(10, 292)
        Me.Label12.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(124, 32)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "Updated"
        '
        'LastUpdatedByTextBox
        '
        Me.LastUpdatedByTextBox.Location = New System.Drawing.Point(149, 252)
        Me.LastUpdatedByTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.LastUpdatedByTextBox.Name = "LastUpdatedByTextBox"
        Me.LastUpdatedByTextBox.ReadOnly = True
        Me.LastUpdatedByTextBox.Size = New System.Drawing.Size(174, 40)
        Me.LastUpdatedByTextBox.TabIndex = 11
        Me.LastUpdatedByTextBox.TabStop = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(10, 248)
        Me.Label11.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(190, 32)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Last Updated:"
        '
        'CreateDateTimePicker
        '
        Me.CreateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.CreateDateTimePicker.Location = New System.Drawing.Point(149, 209)
        Me.CreateDateTimePicker.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.CreateDateTimePicker.Name = "CreateDateTimePicker"
        Me.CreateDateTimePicker.Size = New System.Drawing.Size(174, 40)
        Me.CreateDateTimePicker.TabIndex = 9
        Me.CreateDateTimePicker.TabStop = False
        '
        'AddedByTextBox
        '
        Me.AddedByTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.AddedByTextBox.HideSelection = False
        Me.AddedByTextBox.Location = New System.Drawing.Point(149, 165)
        Me.AddedByTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.AddedByTextBox.MaxLength = 10
        Me.AddedByTextBox.Name = "AddedByTextBox"
        Me.AddedByTextBox.ReadOnly = True
        Me.AddedByTextBox.Size = New System.Drawing.Size(174, 40)
        Me.AddedByTextBox.TabIndex = 8
        Me.AddedByTextBox.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(10, 165)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(148, 32)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Added By:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(10, 209)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(147, 32)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Added on:"
        '
        'UserIDTextBox
        '
        Me.UserIDTextBox.Location = New System.Drawing.Point(149, 74)
        Me.UserIDTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserIDTextBox.MaxLength = 8
        Me.UserIDTextBox.Name = "UserIDTextBox"
        Me.UserIDTextBox.ReadOnly = True
        Me.UserIDTextBox.Size = New System.Drawing.Size(174, 40)
        Me.UserIDTextBox.TabIndex = 5
        Me.UserIDTextBox.TabStop = False
        '
        'PasswordTextBox
        '
        Me.PasswordTextBox.Location = New System.Drawing.Point(149, 121)
        Me.PasswordTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PasswordTextBox.MaxLength = 45
        Me.PasswordTextBox.Name = "PasswordTextBox"
        Me.PasswordTextBox.ReadOnly = True
        Me.PasswordTextBox.Size = New System.Drawing.Size(174, 40)
        Me.PasswordTextBox.TabIndex = 90
        Me.PasswordTextBox.TabStop = False
        '
        'UserIDLabel
        '
        Me.UserIDLabel.AutoSize = True
        Me.UserIDLabel.Location = New System.Drawing.Point(10, 77)
        Me.UserIDLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.UserIDLabel.Name = "UserIDLabel"
        Me.UserIDLabel.Size = New System.Drawing.Size(120, 32)
        Me.UserIDLabel.TabIndex = 3
        Me.UserIDLabel.Text = "User ID:"
        '
        'PassWordLabel
        '
        Me.PassWordLabel.AutoSize = True
        Me.PassWordLabel.Location = New System.Drawing.Point(10, 121)
        Me.PassWordLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.PassWordLabel.Name = "PassWordLabel"
        Me.PassWordLabel.Size = New System.Drawing.Size(142, 32)
        Me.PassWordLabel.TabIndex = 2
        Me.PassWordLabel.Text = "Password:"
        '
        'UserClientTextBox
        '
        Me.UserClientTextBox.AcceptsReturn = True
        Me.UserClientTextBox.Location = New System.Drawing.Point(149, 30)
        Me.UserClientTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserClientTextBox.MaxLength = 3
        Me.UserClientTextBox.Name = "UserClientTextBox"
        Me.UserClientTextBox.ReadOnly = True
        Me.UserClientTextBox.Size = New System.Drawing.Size(85, 40)
        Me.UserClientTextBox.TabIndex = 1
        Me.UserClientTextBox.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 33)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 32)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Client:"
        '
        'UserDataGridView
        '
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Book Antiqua", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserDataGridView.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.UserDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Book Antiqua", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.UserDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.UserDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.UserDataGridView.Location = New System.Drawing.Point(13, 6)
        Me.UserDataGridView.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserDataGridView.Name = "UserDataGridView"
        Me.UserDataGridView.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.UserDataGridView.RowsDefaultCellStyle = DataGridViewCellStyle3
        Me.UserDataGridView.RowTemplate.Height = 33
        Me.UserDataGridView.Size = New System.Drawing.Size(1062, 214)
        Me.UserDataGridView.TabIndex = 19
        '
        'UserIDLabel2
        '
        Me.UserIDLabel2.AutoSize = True
        Me.UserIDLabel2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.UserIDLabel2.Location = New System.Drawing.Point(535, 500)
        Me.UserIDLabel2.Name = "UserIDLabel2"
        Me.UserIDLabel2.Size = New System.Drawing.Size(0, 28)
        Me.UserIDLabel2.TabIndex = 28
        Me.UserIDLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ManageUsers
        '
        Me.AcceptButton = Me.AddButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(15.0!, 28.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1080, 663)
        Me.Controls.Add(Me.UserIDLabel2)
        Me.Controls.Add(Me.CancelButton)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.UpdateButton)
        Me.Controls.Add(Me.ConfirmButton)
        Me.Controls.Add(Me.UserDataGridView)
        Me.Controls.Add(Me.AddButton)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.UserGroupBox)
        Me.Font = New System.Drawing.Font("Book Antiqua", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "ManageUsers"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Manage Users"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.UserGroupBox.ResumeLayout(False)
        Me.UserGroupBox.PerformLayout()
        CType(Me.UserDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ExitButton As Button
    Friend WithEvents UpdateButton As Button
    Friend WithEvents ConfirmButton As Button
    Friend WithEvents AddButton As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents UserZipMaskedTextBox As MaskedTextBox
    Friend WithEvents UserCityTextBox As TextBox
    Friend WithEvents UserStreetTextBox As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents PhoneLabel As Label
    Friend WithEvents UserPhoneMaskedTextBox As MaskedTextBox
    Friend WithEvents UserEmailTextBox As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents UserMiddleTextBox As TextBox
    Friend WithEvents UserLNTextBox As TextBox
    Friend WithEvents UserFNTextBox As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents UserFNLabel As Label
    Friend WithEvents UserGroupBox As GroupBox
    Friend WithEvents CreateDateTimePicker As DateTimePicker
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents UserIDTextBox As TextBox
    Friend WithEvents PasswordTextBox As TextBox
    Friend WithEvents UserIDLabel As Label
    Friend WithEvents PassWordLabel As Label
    Friend WithEvents UserClientTextBox As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents UserDataGridView As DataGridView
    Friend WithEvents UserPasswordTextBox As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents UserTypeComboBox As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents UserGenderComboBox As ComboBox
    Friend WithEvents Label10 As Label
    Friend WithEvents UserDOBDateTimePicker As DateTimePicker
    Friend WithEvents UserStateComboBox As ComboBox
    Friend WithEvents UpdateDateTimePicker As DateTimePicker
    Friend WithEvents Label12 As Label
    Friend WithEvents LastUpdatedByTextBox As TextBox
    Friend WithEvents Label11 As Label
    Public WithEvents UserIDLabel2 As Label
    Friend WithEvents CancelButton As Button
    Friend WithEvents AddedByTextBox As TextBox
End Class
