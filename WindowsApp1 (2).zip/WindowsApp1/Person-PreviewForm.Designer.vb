﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Person_PreviewForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.UserGroupBox = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PersonClientTextBox = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PersonIDTextBox = New System.Windows.Forms.TextBox()
        Me.PasswordTextBox = New System.Windows.Forms.TextBox()
        Me.PersonIDLabel = New System.Windows.Forms.Label()
        Me.PassWordLabel = New System.Windows.Forms.Label()
        Me.DateAddedTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PersonTypeTextBox = New System.Windows.Forms.TextBox()
        Me.BranchIDTextBox = New System.Windows.Forms.TextBox()
        Me.GenderTextBox = New System.Windows.Forms.TextBox()
        Me.PersonAgeTextBox = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.PhoneLabel = New System.Windows.Forms.Label()
        Me.PersonPhoneMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.PersonEmailTextBox = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.NameTextBox = New System.Windows.Forms.TextBox()
        Me.UserFNLabel = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.PersonCityTextBox = New System.Windows.Forms.TextBox()
        Me.PersonStreetTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.PhoneMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.ContactFNTextBox = New System.Windows.Forms.TextBox()
        Me.ContactLNTextBox = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.DOBTextBox = New System.Windows.Forms.TextBox()
        Me.StateTextBox = New System.Windows.Forms.TextBox()
        Me.ZipTextBox = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.UserGroupBox.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'UserGroupBox
        '
        Me.UserGroupBox.BackColor = System.Drawing.Color.Transparent
        Me.UserGroupBox.Controls.Add(Me.Label1)
        Me.UserGroupBox.Controls.Add(Me.PersonClientTextBox)
        Me.UserGroupBox.Controls.Add(Me.Label6)
        Me.UserGroupBox.Controls.Add(Me.PersonIDTextBox)
        Me.UserGroupBox.Controls.Add(Me.PasswordTextBox)
        Me.UserGroupBox.Controls.Add(Me.PersonIDLabel)
        Me.UserGroupBox.Controls.Add(Me.PassWordLabel)
        Me.UserGroupBox.Controls.Add(Me.DateAddedTextBox)
        Me.UserGroupBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserGroupBox.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.UserGroupBox.Location = New System.Drawing.Point(540, 28)
        Me.UserGroupBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserGroupBox.Name = "UserGroupBox"
        Me.UserGroupBox.Padding = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.UserGroupBox.Size = New System.Drawing.Size(401, 255)
        Me.UserGroupBox.TabIndex = 30
        Me.UserGroupBox.TabStop = False
        Me.UserGroupBox.Text = "PERSON ACCESS INFO:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(90, 37)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 32)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Client:"
        '
        'PersonClientTextBox
        '
        Me.PersonClientTextBox.AcceptsReturn = True
        Me.PersonClientTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonClientTextBox.Location = New System.Drawing.Point(213, 28)
        Me.PersonClientTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonClientTextBox.MaxLength = 3
        Me.PersonClientTextBox.Name = "PersonClientTextBox"
        Me.PersonClientTextBox.ReadOnly = True
        Me.PersonClientTextBox.Size = New System.Drawing.Size(85, 41)
        Me.PersonClientTextBox.TabIndex = 1
        Me.PersonClientTextBox.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(16, 205)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(174, 32)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Date Added:"
        '
        'PersonIDTextBox
        '
        Me.PersonIDTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonIDTextBox.Location = New System.Drawing.Point(213, 84)
        Me.PersonIDTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonIDTextBox.MaxLength = 8
        Me.PersonIDTextBox.Name = "PersonIDTextBox"
        Me.PersonIDTextBox.ReadOnly = True
        Me.PersonIDTextBox.Size = New System.Drawing.Size(174, 41)
        Me.PersonIDTextBox.TabIndex = 5
        Me.PersonIDTextBox.TabStop = False
        '
        'PasswordTextBox
        '
        Me.PasswordTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PasswordTextBox.Location = New System.Drawing.Point(213, 140)
        Me.PasswordTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PasswordTextBox.MaxLength = 45
        Me.PasswordTextBox.Name = "PasswordTextBox"
        Me.PasswordTextBox.ReadOnly = True
        Me.PasswordTextBox.Size = New System.Drawing.Size(174, 41)
        Me.PasswordTextBox.TabIndex = 90
        Me.PasswordTextBox.TabStop = False
        '
        'PersonIDLabel
        '
        Me.PersonIDLabel.AutoSize = True
        Me.PersonIDLabel.Location = New System.Drawing.Point(42, 93)
        Me.PersonIDLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.PersonIDLabel.Name = "PersonIDLabel"
        Me.PersonIDLabel.Size = New System.Drawing.Size(148, 32)
        Me.PersonIDLabel.TabIndex = 3
        Me.PersonIDLabel.Text = "Person ID:"
        '
        'PassWordLabel
        '
        Me.PassWordLabel.AutoSize = True
        Me.PassWordLabel.Location = New System.Drawing.Point(48, 149)
        Me.PassWordLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.PassWordLabel.Name = "PassWordLabel"
        Me.PassWordLabel.Size = New System.Drawing.Size(142, 32)
        Me.PassWordLabel.TabIndex = 2
        Me.PassWordLabel.Text = "Password:"
        '
        'DateAddedTextBox
        '
        Me.DateAddedTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.DateAddedTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateAddedTextBox.HideSelection = False
        Me.DateAddedTextBox.Location = New System.Drawing.Point(213, 196)
        Me.DateAddedTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.DateAddedTextBox.MaxLength = 10
        Me.DateAddedTextBox.Name = "DateAddedTextBox"
        Me.DateAddedTextBox.ReadOnly = True
        Me.DateAddedTextBox.Size = New System.Drawing.Size(174, 41)
        Me.DateAddedTextBox.TabIndex = 8
        Me.DateAddedTextBox.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.DOBTextBox)
        Me.GroupBox1.Controls.Add(Me.PersonTypeTextBox)
        Me.GroupBox1.Controls.Add(Me.BranchIDTextBox)
        Me.GroupBox1.Controls.Add(Me.GenderTextBox)
        Me.GroupBox1.Controls.Add(Me.PersonAgeTextBox)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.PhoneLabel)
        Me.GroupBox1.Controls.Add(Me.PersonPhoneMaskedTextBox)
        Me.GroupBox1.Controls.Add(Me.PersonEmailTextBox)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.NameTextBox)
        Me.GroupBox1.Controls.Add(Me.UserFNLabel)
        Me.GroupBox1.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox1.Location = New System.Drawing.Point(13, 281)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(928, 269)
        Me.GroupBox1.TabIndex = 31
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "`"
        '
        'PersonTypeTextBox
        '
        Me.PersonTypeTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.PersonTypeTextBox.Enabled = False
        Me.PersonTypeTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonTypeTextBox.Location = New System.Drawing.Point(718, 200)
        Me.PersonTypeTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonTypeTextBox.MaxLength = 1
        Me.PersonTypeTextBox.Name = "PersonTypeTextBox"
        Me.PersonTypeTextBox.ReadOnly = True
        Me.PersonTypeTextBox.Size = New System.Drawing.Size(176, 41)
        Me.PersonTypeTextBox.TabIndex = 25
        Me.PersonTypeTextBox.TabStop = False
        '
        'BranchIDTextBox
        '
        Me.BranchIDTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.BranchIDTextBox.Enabled = False
        Me.BranchIDTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BranchIDTextBox.Location = New System.Drawing.Point(718, 43)
        Me.BranchIDTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.BranchIDTextBox.MaxLength = 1
        Me.BranchIDTextBox.Name = "BranchIDTextBox"
        Me.BranchIDTextBox.ReadOnly = True
        Me.BranchIDTextBox.Size = New System.Drawing.Size(63, 41)
        Me.BranchIDTextBox.TabIndex = 24
        Me.BranchIDTextBox.TabStop = False
        '
        'GenderTextBox
        '
        Me.GenderTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.GenderTextBox.Enabled = False
        Me.GenderTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GenderTextBox.Location = New System.Drawing.Point(718, 92)
        Me.GenderTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.GenderTextBox.MaxLength = 1
        Me.GenderTextBox.Name = "GenderTextBox"
        Me.GenderTextBox.ReadOnly = True
        Me.GenderTextBox.Size = New System.Drawing.Size(63, 41)
        Me.GenderTextBox.TabIndex = 23
        Me.GenderTextBox.TabStop = False
        '
        'PersonAgeTextBox
        '
        Me.PersonAgeTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.PersonAgeTextBox.Enabled = False
        Me.PersonAgeTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonAgeTextBox.Location = New System.Drawing.Point(127, 145)
        Me.PersonAgeTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonAgeTextBox.MaxLength = 1
        Me.PersonAgeTextBox.Name = "PersonAgeTextBox"
        Me.PersonAgeTextBox.ReadOnly = True
        Me.PersonAgeTextBox.Size = New System.Drawing.Size(63, 41)
        Me.PersonAgeTextBox.TabIndex = 5
        Me.PersonAgeTextBox.TabStop = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(14, 145)
        Me.Label14.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 32)
        Me.Label14.TabIndex = 22
        Me.Label14.Text = "Age:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(552, 43)
        Me.Label13.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(151, 32)
        Me.Label13.TabIndex = 21
        Me.Label13.Text = "Branch ID:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(551, 92)
        Me.Label10.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(117, 32)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "Gender:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(524, 203)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(179, 32)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Person Type:"
        '
        'PhoneLabel
        '
        Me.PhoneLabel.AutoSize = True
        Me.PhoneLabel.Location = New System.Drawing.Point(551, 145)
        Me.PhoneLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.PhoneLabel.Name = "PhoneLabel"
        Me.PhoneLabel.Size = New System.Drawing.Size(125, 32)
        Me.PhoneLabel.TabIndex = 15
        Me.PhoneLabel.Text = "Phone #:"
        '
        'PersonPhoneMaskedTextBox
        '
        Me.PersonPhoneMaskedTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.PersonPhoneMaskedTextBox.Enabled = False
        Me.PersonPhoneMaskedTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonPhoneMaskedTextBox.Location = New System.Drawing.Point(718, 145)
        Me.PersonPhoneMaskedTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PersonPhoneMaskedTextBox.Mask = "(999) 000-0000"
        Me.PersonPhoneMaskedTextBox.Name = "PersonPhoneMaskedTextBox"
        Me.PersonPhoneMaskedTextBox.ReadOnly = True
        Me.PersonPhoneMaskedTextBox.Size = New System.Drawing.Size(176, 41)
        Me.PersonPhoneMaskedTextBox.TabIndex = 8
        '
        'PersonEmailTextBox
        '
        Me.PersonEmailTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.PersonEmailTextBox.Enabled = False
        Me.PersonEmailTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonEmailTextBox.Location = New System.Drawing.Point(127, 200)
        Me.PersonEmailTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonEmailTextBox.Name = "PersonEmailTextBox"
        Me.PersonEmailTextBox.ReadOnly = True
        Me.PersonEmailTextBox.Size = New System.Drawing.Size(285, 41)
        Me.PersonEmailTextBox.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(10, 203)
        Me.Label5.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(95, 32)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Email:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(14, 92)
        Me.Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(91, 32)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "D.O.B"
        '
        'NameTextBox
        '
        Me.NameTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.NameTextBox.Enabled = False
        Me.NameTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NameTextBox.Location = New System.Drawing.Point(127, 40)
        Me.NameTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.NameTextBox.MaxLength = 45
        Me.NameTextBox.Name = "NameTextBox"
        Me.NameTextBox.ReadOnly = True
        Me.NameTextBox.Size = New System.Drawing.Size(285, 41)
        Me.NameTextBox.TabIndex = 0
        '
        'UserFNLabel
        '
        Me.UserFNLabel.AutoSize = True
        Me.UserFNLabel.Location = New System.Drawing.Point(21, 43)
        Me.UserFNLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.UserFNLabel.Name = "UserFNLabel"
        Me.UserFNLabel.Size = New System.Drawing.Size(96, 32)
        Me.UserFNLabel.TabIndex = 1
        Me.UserFNLabel.Text = "Name:"
        '
        'GroupBox2
        '
        Me.GroupBox2.AutoSize = True
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.ZipTextBox)
        Me.GroupBox2.Controls.Add(Me.StateTextBox)
        Me.GroupBox2.Controls.Add(Me.PersonCityTextBox)
        Me.GroupBox2.Controls.Add(Me.PersonStreetTextBox)
        Me.GroupBox2.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox2.Location = New System.Drawing.Point(13, 572)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox2.Size = New System.Drawing.Size(444, 177)
        Me.GroupBox2.TabIndex = 32
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Person Address:"
        '
        'PersonCityTextBox
        '
        Me.PersonCityTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.PersonCityTextBox.Enabled = False
        Me.PersonCityTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonCityTextBox.Location = New System.Drawing.Point(9, 96)
        Me.PersonCityTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonCityTextBox.Name = "PersonCityTextBox"
        Me.PersonCityTextBox.ReadOnly = True
        Me.PersonCityTextBox.Size = New System.Drawing.Size(201, 41)
        Me.PersonCityTextBox.TabIndex = 12
        '
        'PersonStreetTextBox
        '
        Me.PersonStreetTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.PersonStreetTextBox.Enabled = False
        Me.PersonStreetTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonStreetTextBox.Location = New System.Drawing.Point(9, 35)
        Me.PersonStreetTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PersonStreetTextBox.Name = "PersonStreetTextBox"
        Me.PersonStreetTextBox.ReadOnly = True
        Me.PersonStreetTextBox.Size = New System.Drawing.Size(426, 41)
        Me.PersonStreetTextBox.TabIndex = 11
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox4.Controls.Add(Me.PhoneMaskedTextBox)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.ContactFNTextBox)
        Me.GroupBox4.Controls.Add(Me.ContactLNTextBox)
        Me.GroupBox4.Controls.Add(Me.Label22)
        Me.GroupBox4.Controls.Add(Me.Label23)
        Me.GroupBox4.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox4.Location = New System.Drawing.Point(472, 572)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox4.Size = New System.Drawing.Size(469, 191)
        Me.GroupBox4.TabIndex = 39
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Emergency Contact Information:"
        '
        'PhoneMaskedTextBox
        '
        Me.PhoneMaskedTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.PhoneMaskedTextBox.Enabled = False
        Me.PhoneMaskedTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PhoneMaskedTextBox.Location = New System.Drawing.Point(230, 139)
        Me.PhoneMaskedTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.PhoneMaskedTextBox.Mask = "(999) 000-0000"
        Me.PhoneMaskedTextBox.Name = "PhoneMaskedTextBox"
        Me.PhoneMaskedTextBox.ReadOnly = True
        Me.PhoneMaskedTextBox.Size = New System.Drawing.Size(219, 41)
        Me.PhoneMaskedTextBox.TabIndex = 17
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label18.Location = New System.Drawing.Point(8, 142)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(214, 32)
        Me.Label18.TabIndex = 17
        Me.Label18.Text = "Phone Number:"
        '
        'ContactFNTextBox
        '
        Me.ContactFNTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.ContactFNTextBox.Enabled = False
        Me.ContactFNTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContactFNTextBox.Location = New System.Drawing.Point(230, 41)
        Me.ContactFNTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ContactFNTextBox.Name = "ContactFNTextBox"
        Me.ContactFNTextBox.ReadOnly = True
        Me.ContactFNTextBox.Size = New System.Drawing.Size(225, 41)
        Me.ContactFNTextBox.TabIndex = 15
        '
        'ContactLNTextBox
        '
        Me.ContactLNTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.ContactLNTextBox.Enabled = False
        Me.ContactLNTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContactLNTextBox.Location = New System.Drawing.Point(230, 90)
        Me.ContactLNTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ContactLNTextBox.Name = "ContactLNTextBox"
        Me.ContactLNTextBox.ReadOnly = True
        Me.ContactLNTextBox.Size = New System.Drawing.Size(225, 41)
        Me.ContactLNTextBox.TabIndex = 16
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label22.Location = New System.Drawing.Point(47, 50)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(159, 32)
        Me.Label22.TabIndex = 10
        Me.Label22.Text = "First Name:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label23.Location = New System.Drawing.Point(51, 93)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(155, 32)
        Me.Label23.TabIndex = 11
        Me.Label23.Text = "Last Name:"
        '
        'DOBTextBox
        '
        Me.DOBTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.DOBTextBox.Enabled = False
        Me.DOBTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DOBTextBox.Location = New System.Drawing.Point(127, 96)
        Me.DOBTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.DOBTextBox.MaxLength = 45
        Me.DOBTextBox.Name = "DOBTextBox"
        Me.DOBTextBox.ReadOnly = True
        Me.DOBTextBox.Size = New System.Drawing.Size(165, 41)
        Me.DOBTextBox.TabIndex = 26
        '
        'StateTextBox
        '
        Me.StateTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.StateTextBox.Enabled = False
        Me.StateTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StateTextBox.Location = New System.Drawing.Point(244, 96)
        Me.StateTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.StateTextBox.MaxLength = 1
        Me.StateTextBox.Name = "StateTextBox"
        Me.StateTextBox.ReadOnly = True
        Me.StateTextBox.Size = New System.Drawing.Size(63, 41)
        Me.StateTextBox.TabIndex = 15
        Me.StateTextBox.TabStop = False
        '
        'ZipTextBox
        '
        Me.ZipTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.ZipTextBox.Enabled = False
        Me.ZipTextBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ZipTextBox.Location = New System.Drawing.Point(329, 96)
        Me.ZipTextBox.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.ZipTextBox.MaxLength = 1
        Me.ZipTextBox.Name = "ZipTextBox"
        Me.ZipTextBox.ReadOnly = True
        Me.ZipTextBox.Size = New System.Drawing.Size(106, 41)
        Me.ZipTextBox.TabIndex = 16
        Me.ZipTextBox.TabStop = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(140, 816)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(139, 49)
        Me.Button1.TabIndex = 40
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Person_PreviewForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(989, 902)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.UserGroupBox)
        Me.Name = "Person_PreviewForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Person_PreviewForm"
        Me.UserGroupBox.ResumeLayout(False)
        Me.UserGroupBox.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents UserGroupBox As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PersonClientTextBox As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents PersonIDTextBox As TextBox
    Friend WithEvents PasswordTextBox As TextBox
    Friend WithEvents PersonIDLabel As Label
    Friend WithEvents PassWordLabel As Label
    Friend WithEvents DateAddedTextBox As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents PersonTypeTextBox As TextBox
    Friend WithEvents BranchIDTextBox As TextBox
    Friend WithEvents GenderTextBox As TextBox
    Friend WithEvents PersonAgeTextBox As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents PhoneLabel As Label
    Friend WithEvents PersonPhoneMaskedTextBox As MaskedTextBox
    Friend WithEvents PersonEmailTextBox As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents NameTextBox As TextBox
    Friend WithEvents UserFNLabel As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents PersonCityTextBox As TextBox
    Friend WithEvents PersonStreetTextBox As TextBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents PhoneMaskedTextBox As MaskedTextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents ContactFNTextBox As TextBox
    Friend WithEvents ContactLNTextBox As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents DOBTextBox As TextBox
    Friend WithEvents ZipTextBox As TextBox
    Friend WithEvents StateTextBox As TextBox
    Friend WithEvents Button1 As Button
End Class
