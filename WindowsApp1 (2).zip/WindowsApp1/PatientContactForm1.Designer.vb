﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PatientContactInfoForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PatientContactInfoForm))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ContactMethodComboBox = New System.Windows.Forms.ComboBox()
        Me.CellMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.HomeMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.WorkMaskedTextBox1 = New System.Windows.Forms.MaskedTextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ContactMITextBox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.RelationshipTextBox = New System.Windows.Forms.TextBox()
        Me.ContactFNTextBox = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ContactLNTextBox = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.BackButton = New System.Windows.Forms.Button()
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.NextButton = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.PidTextBox = New System.Windows.Forms.TextBox()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.ContactMethodComboBox)
        Me.GroupBox1.Controls.Add(Me.CellMaskedTextBox)
        Me.GroupBox1.Controls.Add(Me.HomeMaskedTextBox)
        Me.GroupBox1.Controls.Add(Me.WorkMaskedTextBox1)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.ContactMITextBox)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.RelationshipTextBox)
        Me.GroupBox1.Controls.Add(Me.ContactFNTextBox)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.ContactLNTextBox)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.GroupBox1.Location = New System.Drawing.Point(50, 147)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(459, 460)
        Me.GroupBox1.TabIndex = 13
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Emergency Contact Information:"
        '
        'ContactMethodComboBox
        '
        Me.ContactMethodComboBox.FormattingEnabled = True
        Me.ContactMethodComboBox.Items.AddRange(New Object() {"Home", "Cell", "Work"})
        Me.ContactMethodComboBox.Location = New System.Drawing.Point(325, 405)
        Me.ContactMethodComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ContactMethodComboBox.Name = "ContactMethodComboBox"
        Me.ContactMethodComboBox.Size = New System.Drawing.Size(107, 40)
        Me.ContactMethodComboBox.TabIndex = 8
        '
        'CellMaskedTextBox
        '
        Me.CellMaskedTextBox.Location = New System.Drawing.Point(207, 303)
        Me.CellMaskedTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.CellMaskedTextBox.Mask = "(999) 000-0000"
        Me.CellMaskedTextBox.Name = "CellMaskedTextBox"
        Me.CellMaskedTextBox.Size = New System.Drawing.Size(219, 40)
        Me.CellMaskedTextBox.TabIndex = 6
        '
        'HomeMaskedTextBox
        '
        Me.HomeMaskedTextBox.Location = New System.Drawing.Point(207, 252)
        Me.HomeMaskedTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.HomeMaskedTextBox.Mask = "(999) 000-0000"
        Me.HomeMaskedTextBox.Name = "HomeMaskedTextBox"
        Me.HomeMaskedTextBox.Size = New System.Drawing.Size(219, 40)
        Me.HomeMaskedTextBox.TabIndex = 5
        '
        'WorkMaskedTextBox1
        '
        Me.WorkMaskedTextBox1.Location = New System.Drawing.Point(207, 354)
        Me.WorkMaskedTextBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.WorkMaskedTextBox1.Mask = "(999) 000-0000"
        Me.WorkMaskedTextBox1.Name = "WorkMaskedTextBox1"
        Me.WorkMaskedTextBox1.Size = New System.Drawing.Size(219, 40)
        Me.WorkMaskedTextBox1.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(8, 409)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(309, 32)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "Best Method of contact:"
        '
        'ContactMITextBox
        '
        Me.ContactMITextBox.Location = New System.Drawing.Point(207, 99)
        Me.ContactMITextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ContactMITextBox.Name = "ContactMITextBox"
        Me.ContactMITextBox.Size = New System.Drawing.Size(225, 40)
        Me.ContactMITextBox.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(8, 101)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(196, 32)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Middle Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(8, 307)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 32)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Cell:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(8, 357)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 32)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Work:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label11.Location = New System.Drawing.Point(8, 255)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(184, 32)
        Me.Label11.TabIndex = 15
        Me.Label11.Text = "Home Phone:"
        '
        'RelationshipTextBox
        '
        Me.RelationshipTextBox.Location = New System.Drawing.Point(207, 201)
        Me.RelationshipTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.RelationshipTextBox.Name = "RelationshipTextBox"
        Me.RelationshipTextBox.Size = New System.Drawing.Size(225, 40)
        Me.RelationshipTextBox.TabIndex = 4
        '
        'ContactFNTextBox
        '
        Me.ContactFNTextBox.Location = New System.Drawing.Point(207, 48)
        Me.ContactFNTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ContactFNTextBox.Name = "ContactFNTextBox"
        Me.ContactFNTextBox.Size = New System.Drawing.Size(225, 40)
        Me.ContactFNTextBox.TabIndex = 1
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.Location = New System.Drawing.Point(8, 204)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(184, 32)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Relationship:"
        '
        'ContactLNTextBox
        '
        Me.ContactLNTextBox.Location = New System.Drawing.Point(207, 150)
        Me.ContactLNTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ContactLNTextBox.Name = "ContactLNTextBox"
        Me.ContactLNTextBox.Size = New System.Drawing.Size(225, 40)
        Me.ContactLNTextBox.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.Location = New System.Drawing.Point(8, 51)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(159, 32)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "First Name:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label10.Location = New System.Drawing.Point(8, 153)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(155, 32)
        Me.Label10.TabIndex = 11
        Me.Label10.Text = "Last Name:"
        '
        'BackButton
        '
        Me.BackButton.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BackButton.Location = New System.Drawing.Point(33, 614)
        Me.BackButton.Name = "BackButton"
        Me.BackButton.Size = New System.Drawing.Size(115, 37)
        Me.BackButton.TabIndex = 14
        Me.BackButton.Text = "&Back"
        Me.BackButton.UseVisualStyleBackColor = False
        '
        'ClearButton
        '
        Me.ClearButton.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClearButton.Location = New System.Drawing.Point(154, 614)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(115, 37)
        Me.ClearButton.TabIndex = 15
        Me.ClearButton.Text = "&Clear"
        Me.ClearButton.UseVisualStyleBackColor = False
        '
        'NextButton
        '
        Me.NextButton.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.NextButton.Location = New System.Drawing.Point(279, 614)
        Me.NextButton.Name = "NextButton"
        Me.NextButton.Size = New System.Drawing.Size(115, 37)
        Me.NextButton.TabIndex = 9
        Me.NextButton.Text = "&Next"
        Me.NextButton.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(18, 68)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(255, 32)
        Me.Label5.TabIndex = 27
        Me.Label5.Text = "Patient First Name:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(18, 108)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(251, 32)
        Me.Label6.TabIndex = 28
        Me.Label6.Text = "Patient Last Name:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(18, 28)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(151, 32)
        Me.Label7.TabIndex = 29
        Me.Label7.Text = "Patient ID:"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(281, 108)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(181, 40)
        Me.TextBox1.TabIndex = 27
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(281, 64)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(181, 40)
        Me.TextBox2.TabIndex = 28
        '
        'PidTextBox
        '
        Me.PidTextBox.Location = New System.Drawing.Point(281, 20)
        Me.PidTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.PidTextBox.Name = "PidTextBox"
        Me.PidTextBox.ReadOnly = True
        Me.PidTextBox.Size = New System.Drawing.Size(133, 40)
        Me.PidTextBox.TabIndex = 29
        '
        'ExitButton
        '
        Me.ExitButton.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ExitButton.Location = New System.Drawing.Point(411, 614)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(115, 37)
        Me.ExitButton.TabIndex = 30
        Me.ExitButton.Text = "Ex&it"
        Me.ExitButton.UseVisualStyleBackColor = False
        '
        'PatientContactInfoForm
        '
        Me.AcceptButton = Me.NextButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(17.0!, 32.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(558, 663)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.PidTextBox)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.NextButton)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.BackButton)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Book Antiqua", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "PatientContactInfoForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CONTACT INFORMATION"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label11 As Label
    Friend WithEvents RelationshipTextBox As TextBox
    Friend WithEvents ContactFNTextBox As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents ContactLNTextBox As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents ContactMITextBox As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents WorkMaskedTextBox1 As MaskedTextBox
    Friend WithEvents ContactMethodComboBox As ComboBox
    Friend WithEvents CellMaskedTextBox As MaskedTextBox
    Friend WithEvents HomeMaskedTextBox As MaskedTextBox
    Friend WithEvents BackButton As Button
    Friend WithEvents ClearButton As Button
    Friend WithEvents NextButton As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents PidTextBox As TextBox
    Friend WithEvents ExitButton As Button
End Class
