﻿Public Class PatientBillingForm
    Private Sub PatientBillingForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub PreviewButton_Click(sender As Object, e As EventArgs) Handles PreviewButton.Click

    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Dim result = MessageBox.Show("All unsaved data and changes will be lost." & vbCrLf & "Are you sure you want to exit the patient entry form?", "Are you sure?", MessageBoxButtons.YesNoCancel)
        If result = DialogResult.Yes Then

            AddPatientForm.Close()
            HomeForm.Show()
            Me.Close()
        End If
    End Sub

    Private Sub BackButton_Click(sender As Object, e As EventArgs) Handles BackButton.Click
        PatientContactInfoForm.Show()
        Me.Close()
    End Sub
End Class