﻿Imports System.Data.Common
Public Class AddPatientForm
    Public Property StringPass As String
    Private DB As New DBAccess
    Public SQLstr As String
    Public Dbreader As String
    Private currentrecord As Integer = 0
    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function
    Private Sub PatientForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        StringPass = StringPassLabel.Text

        'add code for patient datagridview.readonly = true

        DB.ExecuteQuery("Select * From Patient1")
        If DB.Exception <> String.Empty Then
            MessageBox.Show(DB.Exception)
            Exit Sub

        End If
    End Sub
    Private Sub HomeButton_Click(sender As Object, e As EventArgs) Handles HomeButton.Click
        HomeForm.ShowDialog()
    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Dim result = MessageBox.Show(" Are you sure you want to quit", "All unsaved data will be lost", MessageBoxButtons.YesNoCancel)
        If result = DialogResult.Yes Then
            HomeForm.ShowDialog()
            Me.Close()
        End If
    End Sub
    Private Sub NextButton_Click(sender As System.Object, e As System.EventArgs) Handles NextButton.Click
        PatientIDTextBox.Text = PatientLNTextBox.Text.Substring(0, 5) + "1" + PatientFNTextBox.Text.Substring(0, 2)

        If PatientFNTextBox.Text = "" Then
            MessageBox.Show("First name textbox cannot be left empty", "Missing Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            PatientFNTextBox.Focus()
        ElseIf MiddleNameTextBox.Text = "" Then
            MessageBox.Show("Middle name textbox cannot be left empty", "Missing Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            MiddleNameTextBox.Focus()
        ElseIf PatientLNTextBox.Text = "" Then
            MessageBox.Show("Last name textbox cannot be left empty", "Missing Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            PatientLNTextBox.Focus()
        ElseIf PatientDOBDateTimePicker.Value = Today Then
            MessageBox.Show("Date of birth cannot be left Empty.", "Missing Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            PatientDOBDateTimePicker.Focus()
        ElseIf LocationComboBox.Text = "" Then
            MessageBox.Show("Please select specific which location the patient is at.", "Missing Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            LocationComboBox.Focus()

        Else
            DB.AddParam("@PatientID", PatientIDTextBox.Text)
            DB.AddParam("@PatientFirstName", PatientFNTextBox.Text)
            DB.AddParam("@PatientMiddleName", MiddleNameTextBox.Text)
            DB.AddParam("@PatientLastName", PatientLNTextBox.Text)
            DB.AddParam("@PatientBirthDate", PatientDOBDateTimePicker.Value)
            DB.AddParam("@PatientAge", PatientAgeTextBox.Text)
            DB.AddParam("@PatientLocation", LocationComboBox.Text)
            DB.AddParam("@PatientMedications", MedicationTextBox.Text)
            DB.AddParam("@PatientNotes", NotesTextBox.Text)
            DB.AddParam("@PatientAddedBy", StringPassLabel.Text)
            DB.AddParam("@DateAdded", DateTimePicker1.Value)

            DB.ExecuteQuery("INSERT INTO Patient1(PatientID, PatientFirstName, PatientMiddleInitial, PatientLastName, PatientBirthDate, PatientAge, PatientLocation, PatientMedications, PatientNotes, PatientAddedBy, DateAdded) Values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")


            MessageBox.Show("Please verify all patient information is correct before moving on.")

            If DB.Exception <> String.Empty Then
                MessageBox.Show(DB.Exception)
                Exit Sub
            End If


            Dim obj As New PatientContactInfoForm
            LoginForm.UserIDLabel.Text = UserIDLabel.Text
            obj.ShowDialog()
            Me.Hide()
        End If
    End Sub

    Private Sub BackButton_Click(sender As Object, e As EventArgs) Handles BackButton.Click
        PatientOption.ShowDialog()
        Me.Close()
    End Sub

    Private Sub StringPassLabel_Click(sender As Object, e As EventArgs) Handles StringPassLabel.Click
        StringPassLabel.Text = Passwordform.UserIDLabel.ToString
    End Sub
End Class
