﻿Public Class ReportsForm
    Private Sub EventLog1_EntryWritten(sender As Object, e As EntryWrittenEventArgs)

    End Sub

    Private Sub PrintPreviewControl1_Click(sender As Object, e As EventArgs)

    End Sub
End Class