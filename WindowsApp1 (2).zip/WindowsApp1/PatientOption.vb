﻿Public Class PatientOption
    Public Property StringPass As String
    Private DB As New DBAccess
    Private Sub AddButton_Click(sender As Object, e As EventArgs) Handles AddButton.Click
        Dim obj As New AddPatientForm
        obj.Show()
        Me.Hide()
        AddPatientForm.Show()
        Exit Sub

    End Sub

    Private Sub HomeButton_Click(sender As Object, e As EventArgs) Handles HomeButton.Click
        HomeForm.ShowDialog()
    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Dim result = MessageBox.Show("All unsaved data and changes will be lost." & vbCrLf & "Are you sure you want to exit the patient entry form?", "Are you sure?", MessageBoxButtons.YesNoCancel)
        If result = DialogResult.Yes Then
            Me.Close()
            AddPatientForm.Close()

        End If
    End Sub

    Private Sub PatientOption_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If LoginForm.ClientComboBox.SelectedItem = "901" Then
            AddButton.Enabled = True
            EditButton.Enabled = True
            SearchButton.Enabled = True
        ElseIf LoginForm.ClientComboBox.SelectedItem = "902" Then
            AddButton.Enabled = False
            EditButton.Enabled = False
            SearchButton.Enabled = True
        ElseIf LoginForm.ClientComboBox.SelectedItem = "903" Then
            AddButton.Enabled = False
            EditButton.Enabled = False
            SearchButton.Enabled = False
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles SearchButton.Click
        Dim obj As New PatientSearch
        obj.Show()
        Me.Hide()
        PatientSearch.ShowDialog()
    End Sub
End Class