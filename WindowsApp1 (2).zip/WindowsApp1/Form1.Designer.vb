﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Splitter1 = New System.Windows.Forms.Splitter()
        Me.PageSetupDialog1 = New System.Windows.Forms.PageSetupDialog()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.PatientsButton = New System.Windows.Forms.Button()
        Me.UsersButton = New System.Windows.Forms.Button()
        Me.PersonsButton = New System.Windows.Forms.Button()
        Me.EmployeeButton = New System.Windows.Forms.Button()
        Me.ReportButton = New System.Windows.Forms.Button()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Splitter1
        '
        Me.Splitter1.Location = New System.Drawing.Point(0, 0)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(3, 853)
        Me.Splitter1.TabIndex = 2
        Me.Splitter1.TabStop = False
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Location = New System.Drawing.Point(9, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.ExitButton)
        Me.SplitContainer1.Panel1.Controls.Add(Me.PatientsButton)
        Me.SplitContainer1.Panel1.Controls.Add(Me.UsersButton)
        Me.SplitContainer1.Panel1.Controls.Add(Me.PersonsButton)
        Me.SplitContainer1.Panel1.Controls.Add(Me.EmployeeButton)
        Me.SplitContainer1.Panel1.Controls.Add(Me.ReportButton)
        Me.SplitContainer1.Size = New System.Drawing.Size(1602, 700)
        Me.SplitContainer1.SplitterDistance = 256
        Me.SplitContainer1.TabIndex = 3
        '
        'ExitButton
        '
        Me.ExitButton.BackColor = System.Drawing.SystemColors.Window
        Me.ExitButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExitButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ExitButton.Location = New System.Drawing.Point(42, 511)
        Me.ExitButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(206, 53)
        Me.ExitButton.TabIndex = 7
        Me.ExitButton.Text = "E&XIT"
        Me.ExitButton.UseVisualStyleBackColor = False
        '
        'PatientsButton
        '
        Me.PatientsButton.BackColor = System.Drawing.SystemColors.Window
        Me.PatientsButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PatientsButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.PatientsButton.Location = New System.Drawing.Point(42, 178)
        Me.PatientsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PatientsButton.Name = "PatientsButton"
        Me.PatientsButton.Size = New System.Drawing.Size(206, 53)
        Me.PatientsButton.TabIndex = 6
        Me.PatientsButton.Text = "&PATIENTS"
        Me.PatientsButton.UseVisualStyleBackColor = False
        '
        'UsersButton
        '
        Me.UsersButton.BackColor = System.Drawing.SystemColors.Window
        Me.UsersButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UsersButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.UsersButton.Location = New System.Drawing.Point(42, 443)
        Me.UsersButton.Margin = New System.Windows.Forms.Padding(4)
        Me.UsersButton.Name = "UsersButton"
        Me.UsersButton.Size = New System.Drawing.Size(206, 53)
        Me.UsersButton.TabIndex = 11
        Me.UsersButton.Text = "&USERS"
        Me.UsersButton.UseVisualStyleBackColor = False
        '
        'PersonsButton
        '
        Me.PersonsButton.BackColor = System.Drawing.SystemColors.Window
        Me.PersonsButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PersonsButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.PersonsButton.Location = New System.Drawing.Point(42, 246)
        Me.PersonsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PersonsButton.Name = "PersonsButton"
        Me.PersonsButton.Size = New System.Drawing.Size(206, 53)
        Me.PersonsButton.TabIndex = 10
        Me.PersonsButton.Text = "&PERSON"
        Me.PersonsButton.UseVisualStyleBackColor = False
        '
        'EmployeeButton
        '
        Me.EmployeeButton.BackColor = System.Drawing.SystemColors.Window
        Me.EmployeeButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmployeeButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.EmployeeButton.Location = New System.Drawing.Point(42, 375)
        Me.EmployeeButton.Margin = New System.Windows.Forms.Padding(4)
        Me.EmployeeButton.Name = "EmployeeButton"
        Me.EmployeeButton.Size = New System.Drawing.Size(206, 53)
        Me.EmployeeButton.TabIndex = 9
        Me.EmployeeButton.Text = "&EMPLOYEES"
        Me.EmployeeButton.UseVisualStyleBackColor = False
        '
        'ReportButton
        '
        Me.ReportButton.BackColor = System.Drawing.SystemColors.Window
        Me.ReportButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReportButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ReportButton.Location = New System.Drawing.Point(42, 314)
        Me.ReportButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ReportButton.Name = "ReportButton"
        Me.ReportButton.Size = New System.Drawing.Size(206, 53)
        Me.ReportButton.TabIndex = 8
        Me.ReportButton.Text = "&REPORTS"
        Me.ReportButton.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1987, 853)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.Splitter1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Splitter1 As Splitter
    Friend WithEvents PageSetupDialog1 As PageSetupDialog
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents ExitButton As Button
    Friend WithEvents PatientsButton As Button
    Friend WithEvents UsersButton As Button
    Friend WithEvents PersonsButton As Button
    Friend WithEvents EmployeeButton As Button
    Friend WithEvents ReportButton As Button
End Class
