﻿Imports System.Data.Common
Public Class ManageUsers
    Public Property StringPass As String
    Private DB As New DBAccess
    Public SQLString As String
    Public DBreader As String
    Private currentreccord As Integer = 0
    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function

    Private Sub ManageUsers_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        UserDataGridView.Enabled = False
        UserDataGridView.ReadOnly = True
        CreateDateTimePicker.Enabled = False
        UpdateDateTimePicker.Enabled = False

        DB.ExecuteQuery("Select (UserID, UserClient, UserPassword, UserFirstName, UserMiddleInitial, UserLastName, UserDOB, UserGender, UserPhoneNumber, UserType, UserEmail, UserAddress, UserCity, UserState, UserZip, DateGrantedAccess) From User")
        DB.ExecuteQuery("Select * From User")
        If DB.Exception <> String.Empty Then
            MessageBox.Show(DB.Exception)
            Exit Sub

        End If
        'Fill data grid. 
        UserDataGridView.DataSource = DB.DBDataTable
        'Show user logged in

        HomeForm.UserIDLabel.Text = AddedByTextBox.Text

        'Enable/Disable User Information
        UserFNTextBox.ReadOnly = True
        UserMiddleTextBox.ReadOnly = True
        UserLNTextBox.ReadOnly = True
        UserDOBDateTimePicker.Enabled = False
        UserGenderComboBox.Enabled = False
        UserPhoneMaskedTextBox.ReadOnly = True
        UserEmailTextBox.ReadOnly = True
        UserPasswordTextBox.ReadOnly = True
        UserTypeComboBox.Enabled = False

        'Enable/Disable User Address
        UserStreetTextBox.ReadOnly = True
        UserCityTextBox.ReadOnly = True
        UserStreetTextBox.ReadOnly = True
        UserZipMaskedTextBox.ReadOnly = True

        'enable/disable user access info
        UserClientTextBox.ReadOnly = True
        UserIDTextBox.ReadOnly = True
        UserPasswordTextBox.ReadOnly = True
        AddedByTextBox.ReadOnly = True
        CreateDateTimePicker.Enabled = False
        LastUpdatedByTextBox.ReadOnly = True

        'enable/disable buttons
        ConfirmButton.Enabled = False
    End Sub

    Private Sub CancelButton_Click(sender As Object, e As EventArgs) Handles CancelButton.Click
        UserClientTextBox.Clear()
        UserIDTextBox.Clear()
        UserPasswordTextBox.Clear()
        UserFNTextBox.Clear()
        UserMiddleTextBox.Clear()
        UserLNTextBox.Clear()
        UserDOBDateTimePicker.Value = Today
        UserGenderComboBox.Text = ""
        UserTypeComboBox.Text = ""
        UserEmailTextBox.Clear()
        UserPhoneMaskedTextBox.Clear()
        UserTypeComboBox.ResetText()
        UserStreetTextBox.Clear()
        UserCityTextBox.Clear()
        UserStateComboBox.Text = ""
        UserZipMaskedTextBox.Clear()
        PasswordTextBox.Clear()
        UserStateComboBox.Text = ""

        'Enable/disbale buttons
        AddButton.Enabled = True
        ConfirmButton.Enabled = False
        UpdateButton.Enabled = True
        CancelButton.Enabled = True

    End Sub
    Private Sub AddButton_Click(sender As Object, e As EventArgs) Handles AddButton.Click
        'disable datagrid cell click
        UserDataGridView.Enabled = False
        'Enable/Disable User Information
        UserFNTextBox.ReadOnly = False
        UserMiddleTextBox.ReadOnly = False
        UserLNTextBox.ReadOnly = False
        UserDOBDateTimePicker.Enabled = True
        UserGenderComboBox.Enabled = True
        UserPhoneMaskedTextBox.ReadOnly = False
        UserEmailTextBox.ReadOnly = False
        UserPasswordTextBox.ReadOnly = False
        UserTypeComboBox.Enabled = True

        'Enable/Disable User Address
        UserStreetTextBox.ReadOnly = False
        UserCityTextBox.ReadOnly = False
        UserStreetTextBox.ReadOnly = False
        UserZipMaskedTextBox.ReadOnly = False

        'enable/disable user access info
        UserClientTextBox.ReadOnly = True
        UserIDTextBox.ReadOnly = True
        PasswordTextBox.ReadOnly = True
        AddedByTextBox.ReadOnly = True
        CreateDateTimePicker.Enabled = False
        LastUpdatedByTextBox.ReadOnly = True
        AddedByTextBox.Text = UserID

        'enable/disable buttons
        ConfirmButton.Enabled = False
        UpdateButton.Enabled = False

        'Record new user's user ID
        If UserFNTextBox.Text = "" Then
            MessageBox.Show("Please enter the following information before moving on:" & vbNewLine & "-first name:" & vbNewLine & "-Middle inital" & vbNewLine & "-Last name:" & vbNewLine & "-Users DOB:" & vbNewLine & "-Gender" & vbNewLine & "-Phone Number:" & vbNewLine & "-Password:" & vbNewLine & "-User Type:" & vbNewLine & "-User Email Address:")
            UserFNTextBox.Focus()
        ElseIf UserFNTextBox.Text = "" Then
            MessageBox.Show("First Name cannot be left emptpy!")
            UserFNTextBox.Focus()
        ElseIf UserMiddleTextBox.Text = "" Then
            MessageBox.Show("Please enter the users middle intial")
            UserMiddleTextBox.Focus()
        ElseIf UserLNTextBox.Text = "" Then
            MessageBox.Show("Please enter the users last name")
            UserLNTextBox.Focus()
        ElseIf UserDOBDateTimePicker.Value = Today Then
            MessageBox.Show("Date of birth cannot be left empty!")
            UserDOBDateTimePicker.Focus()
        ElseIf UserGenderComboBox.Text = "" Then
            MessageBox.Show("Please select gender")
            UserGenderComboBox.Focus()
        ElseIf UserPhoneMaskedTextBox.Text = "" Then
            MessageBox.Show("Please enter the users phone number.")
            UserPhoneMaskedTextBox.Focus()
        ElseIf UserPasswordTextBox.Text = "" Then
            MessageBox.Show("Please enter the users password")
            UserPasswordTextBox.Focus()
        ElseIf UserTypeComboBox.Text = "" Then
            MessageBox.Show("Please select a user type")
            UserTypeComboBox.Focus()
        ElseIf UserEmailTextBox.Text = "" Then
            MessageBox.Show("Please enter the users email or N/A")
            UserEmailTextBox.Focus()
        ElseIf UserStreetTextBox.Text = "" Then
            MessageBox.Show("Street address cannot be left empty!")
            UserStreetTextBox.Focus()
        ElseIf UserCityTextBox.Text = "" Then
            MessageBox.Show("City cannot be left empty")
            UserCityTextBox.Focus()
        ElseIf UserStateComboBox.Text = "" Then
            MessageBox.Show("State cannot be left empty!")
            UserStateComboBox.Focus()
        ElseIf UserZipMaskedTextBox.Text = "" Then
            MessageBox.Show("Zipcode cannot be left empty")
            UserZipMaskedTextBox.Focus()

        Else
            UserIDTextBox.Text = UserLNTextBox.Text.Substring(0, 5) + "1" + UserFNTextBox.Text.Substring(0, 1)
            PasswordTextBox.Text = UserPasswordTextBox.Text
            If UserTypeComboBox.SelectedItem = "ADMIN" Then
                UserClientTextBox.Text = "901"
            ElseIf UserTypeComboBox.SelectedItem = "EMPLOYEE" Then
                UserClientTextBox.Text = "902"
            ElseIf UserTypeComboBox.SelectedItem = "PATIENT" Then
                UserClientTextBox.Text = "903"
            End If
            '--------------User Information---------------------------------------------------
            Dim result = MessageBox.Show("Please verify all information is correct, than press confirm to add a new user", "Is this information correct?", MessageBoxButtons.YesNo)
            If result = DialogResult.Yes Then
                'enable confirm button
                ConfirmButton.Enabled = True
                AddButton.Enabled = False
                'Enable/ Disable User Information
                UserFNTextBox.ReadOnly = True
                UserMiddleTextBox.ReadOnly = True
                UserLNTextBox.ReadOnly = True
                UserDOBDateTimePicker.Enabled = False
                UserGenderComboBox.Enabled = False
                UserPhoneMaskedTextBox.ReadOnly = True
                UserEmailTextBox.ReadOnly = True
                UserPasswordTextBox.ReadOnly = True
                UserTypeComboBox.Enabled = False
                UserStreetTextBox.ReadOnly = True
                UserCityTextBox.ReadOnly = True
                UserStreetTextBox.ReadOnly = True
                UserZipMaskedTextBox.ReadOnly = True
            End If
        End If
    End Sub
    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Dim result = MessageBox.Show("Are you sure you want to exit now? All unsaved changes will be lost immediately", "Are you sure?", MessageBoxButtons.YesNoCancel)
        If result = DialogResult.Yes Then
            HomeForm.Show()
            Me.Close()
        End If
    End Sub
    Private Sub UserDataGridView_CellContentClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles UserDataGridView.CellContentClick
        If e.RowIndex < 0 Or e.ColumnIndex < 0 Then
            Exit Sub
        End If

        UserIDTextBox.Text = UserDataGridView.Item(0, e.RowIndex).Value.ToString
        UserClientTextBox.Text = UserDataGridView.Item(1, e.RowIndex).Value.ToString
        PasswordTextBox.Text = UserDataGridView.Item(2, e.RowIndex).Value.ToString
        UserFNTextBox.Text = UserDataGridView.Item(3, e.RowIndex).Value.ToString
        UserMiddleTextBox.Text = UserDataGridView.Item(4, e.RowIndex).Value.ToString
        UserLNTextBox.Text = UserDataGridView.Item(5, e.RowIndex).Value.ToString
        UserDOBDateTimePicker.Text = UserDataGridView.Item(6, e.RowIndex).Value
        UserGenderComboBox.Text = UserDataGridView.Item(7, e.RowIndex).Value.ToString
        UserPhoneMaskedTextBox.Text = UserDataGridView.Item(8, e.RowIndex).Value.ToString
        UserTypeComboBox.Text = UserDataGridView.Item(9, e.RowIndex).Value.ToString
        UserEmailTextBox.Text = UserDataGridView.Item(10, e.RowIndex).Value.ToString
        UserStreetTextBox.Text = UserDataGridView.Item(11, e.RowIndex).Value.ToString
        UserCityTextBox.Text = UserDataGridView.Item(12, e.RowIndex).Value.ToString
        UserStateComboBox.Text = UserDataGridView.Item(13, e.RowIndex).Value.ToString
        UserZipMaskedTextBox.Text = UserDataGridView.Item(14, e.RowIndex).Value.ToString
        CreateDateTimePicker.Text = UserDataGridView.Item(15, e.RowIndex).Value
        AddedByTextBox.Text = UserDataGridView.Item(16, e.RowIndex).Value.ToString
        LastUpdatedByTextBox.Text = UserDataGridView.Item(17, e.RowIndex).Value.ToString
        UpdateDateTimePicker.Value = UserDataGridView.Item(18, e.RowIndex).Value.DBNUll


        CancelButton.Enabled = True
        ConfirmButton.Enabled = True
        AddButton.Enabled = False
        ConfirmButton.Enabled = False
        UpdateDateTimePicker.Value = Today


        'enabled/disabled
        UserClientTextBox.ReadOnly = True
        UserIDTextBox.ReadOnly = True
        UserPasswordTextBox.ReadOnly = False
        UserFNTextBox.ReadOnly = False
        UserMiddleTextBox.ReadOnly = False
        UserLNTextBox.ReadOnly = False
        UserDOBDateTimePicker.Enabled = True
        UserEmailTextBox.ReadOnly = False
        UserPhoneMaskedTextBox.ReadOnly = False
        UserTypeComboBox.Enabled = True
        UserStreetTextBox.ReadOnly = False
        UserCityTextBox.ReadOnly = False
        UserZipMaskedTextBox.ReadOnly = False
    End Sub

    Private Sub ConfirmButton_Click(sender As Object, e As EventArgs) Handles ConfirmButton.Click
        If UserFNTextBox.Text = "" Then
            MessageBox.Show("Please enter the users first name")
        ElseIf UserPasswordTextBox.Text = "" Then
            MessageBox.Show("Please enter the users password")
        Else

            DB.AddParam("@UserID", UserIDTextBox.Text)
            DB.AddParam("@UserClient", UserClientTextBox.Text)
            DB.AddParam("@UserPassWord", UserPasswordTextBox.Text)
            DB.AddParam("@UserFirstName", UserFNTextBox.Text)
            DB.AddParam("@UserMiddleInitial", UserMiddleTextBox.Text)
            DB.AddParam("@UserLastName", UserLNTextBox.Text)
            DB.AddParam("@UserBirthDate", UserDOBDateTimePicker.Value)
            DB.AddParam("@UserGender", UserGenderComboBox.Text)
            DB.AddParam("@UserPhoneNumber", UserPhoneMaskedTextBox.TextMaskFormat)
            DB.AddParam("@UserType", UserTypeComboBox.Text)
            DB.AddParam("@UserEmail", UserEmailTextBox.Text)
            DB.AddParam("@UserStreet", UserStreetTextBox.Text)
            DB.AddParam("@UserCity", UserCityTextBox.Text)
            DB.AddParam("@UserState", UserStateComboBox.Text)
            DB.AddParam("@UserZip", UserZipMaskedTextBox.Text)
            DB.AddParam("@DateGrantedAccess", CreateDateTimePicker.Value)
            DB.AddParam("@AddedBy", AddedByTextBox.Text)

            DB.ExecuteQuery("INSERT INTO User(UserID, UserClient, UserPassword, UserFirstName, UserMiddleInitial, UserLastName, UserBirthDate, UserGender, UserPhoneNumber, UserType, UserEmail, UserStreet, UserCity, UserState, UserZip, DateGrantedAccess, AddedBy) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")

            If DB.Exception <> String.Empty Then
                MessageBox.Show(DB.Exception)
                Exit Sub
            End If

            'success
            MessageBox.Show("A new user has been granted access.")

            'refresh table
            UserDataGridView.ReadOnly = True
            DB.ExecuteQuery("Select * from User")
            If DB.Exception <> String.Empty Then
                MessageBox.Show(DB.Exception)
                Exit Sub
            End If

            'Fill datagrid cell click
            UserDataGridView.DataSource = DB.DBDataTable
            'enable datagrid cell click
            UserDataGridView.Enabled = True

            'disable text boxs
            UserClientTextBox.ReadOnly = True
            PasswordTextBox.ReadOnly = True
            UserIDTextBox.ReadOnly = True
            AddedByTextBox.ReadOnly = True
            CreateDateTimePicker.Enabled = False
            UserDOBDateTimePicker.Enabled = True
            CreateDateTimePicker.Value = Today
            AddButton.Enabled = True
            CancelButton.Enabled = True
            ConfirmButton.Enabled = False

            UserClientTextBox.Clear()
            UserIDTextBox.Clear()
            UserPasswordTextBox.Clear()
            PasswordTextBox.Clear()
            UserFNTextBox.Clear()
            UserMiddleTextBox.Clear()
            UserLNTextBox.Clear()
            UserDOBDateTimePicker.Value = Today
            UserEmailTextBox.Clear()
            UserPhoneMaskedTextBox.Clear()
            UserTypeComboBox.Text = ""
            UserStreetTextBox.Clear()
            UserCityTextBox.Clear()
            UserZipMaskedTextBox.Clear()
            Exit Sub
        End If
    End Sub

    Private Sub UpdateButton_Click(sender As Object, e As EventArgs) Handles UpdateButton.Click
        If UserFNTextBox.Text = "" Then
            MessageBox.Show("Please enter Name.")
        ElseIf UserPasswordTextBox.Text = "" Then
            MessageBox.Show("Please enter Password.")
        Else
            If String.IsNullOrEmpty(UserFNTextBox.Text) Then
                Exit Sub
            End If
            DB.AddParam("@UserID", UserIDTextBox.Text)
            DB.AddParam("@UserClient", UserClientTextBox.Text)
            DB.AddParam("@UserPassWord", UserPasswordTextBox.Text)
            DB.AddParam("@UserFirstName", UserFNTextBox.Text)
            DB.AddParam("@UserMiddleInitial", UserMiddleTextBox.Text)
            DB.AddParam("@UserLastName", UserLNTextBox.Text)
            DB.AddParam("@UserBirthDate", UserDOBDateTimePicker.Value)
            DB.AddParam("@UserGender", UserGenderComboBox.Text)
            DB.AddParam("@UserPhoneNumber", UserPhoneMaskedTextBox.TextMaskFormat)
            DB.AddParam("@UserType", UserTypeComboBox.Text)
            DB.AddParam("@UserEmail", UserEmailTextBox.Text)
            DB.AddParam("@UserStreet", UserStreetTextBox.Text)
            DB.AddParam("@UserCity", UserCityTextBox.Text)
            DB.AddParam("@UserState", UserStateComboBox.Text)
            DB.AddParam("@UserZip", UserZipMaskedTextBox.Text)
            DB.AddParam("@LastUpdate", UpdateDateTimePicker.Value)
            DB.AddParam("@UpdatedBy", LastUpdatedByTextBox.Text)

            DB.ExecuteQuery("UPDATE IGNORE User SET UserID = ?, UserClient = ?, UserPassword = ?, UserFirstName = ?, UserMiddleInitial = ?, UserLastName = ?, UserBirthDate = ?, UserGender = ?, UserPhoneNumber = ?, UserType = ?, UserEmail = ?, UserStreet = ?, UserCity = ?, UserState = ?, UserZip = ?, DateUpdated = ?")
            'Catch error
            If NotEmpty(DB.Exception) Then
                MessageBox.Show(DB.Exception)
                Exit Sub
            Else
                MessageBox.Show("User is updated successfully.")
            End If

            'Enable DataGrid Cell click
            UserDataGridView.Enabled = True

            'Enable/Disable User Information
            UserFNTextBox.ReadOnly = True
            UserMiddleTextBox.ReadOnly = True
            UserLNTextBox.ReadOnly = True
            UserDOBDateTimePicker.Enabled = False
            UserGenderComboBox.Enabled = False
            UserPhoneMaskedTextBox.ReadOnly = True
            UserEmailTextBox.ReadOnly = True
            UserPasswordTextBox.ReadOnly = True
            UserTypeComboBox.Enabled = False

            'Enable/Disable User Address
            UserStreetTextBox.ReadOnly = True
            UserCityTextBox.ReadOnly = True
            UserStreetTextBox.ReadOnly = True
            UserZipMaskedTextBox.ReadOnly = True

            'enable/disable user access info
            UserClientTextBox.ReadOnly = True
            UserIDTextBox.ReadOnly = True
            UserPasswordTextBox.ReadOnly = True
            AddedByTextBox.ReadOnly = True
            CreateDateTimePicker.Enabled = False
            LastUpdatedByTextBox.ReadOnly = True

            'enable buttons
            AddButton.Enabled = True
            ConfirmButton.Enabled = False
            CancelButton.Enabled = False

            'Refresh table
            UserDataGridView.ReadOnly = True

            DB.ExecuteQuery("Select * From User")
            If DB.Exception <> String.Empty Then
                MessageBox.Show(DB.Exception)
                Exit Sub
            End If

            'Fill Data grid
            UserDataGridView.DataSource = DB.DBDataTable
            UserClientTextBox.Clear()
            UserIDTextBox.Clear()
            UserPasswordTextBox.Clear()
            PasswordTextBox.Clear()
            UserFNTextBox.Clear()
            UserMiddleTextBox.Clear()
            UserLNTextBox.Clear()
            UserDOBDateTimePicker.Value = Today
            UserEmailTextBox.Clear()
            UserPhoneMaskedTextBox.Clear()
            UserTypeComboBox.Text = ""
            UserStreetTextBox.Clear()
            UserCityTextBox.Clear()
            UserZipMaskedTextBox.Clear()
        End If
    End Sub


End Class