﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AddPatientForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AddPatientForm))
        Me.PatientGroupBox = New System.Windows.Forms.GroupBox()
        Me.PatientDOBDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.LocationComboBox = New System.Windows.Forms.ComboBox()
        Me.BIS425BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BIS425 = New WindowsApp1.BIS425()
        Me.PatientMNLabel = New System.Windows.Forms.Label()
        Me.MiddleNameTextBox = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.NotesTextBox = New System.Windows.Forms.TextBox()
        Me.MedicationTextBox = New System.Windows.Forms.TextBox()
        Me.PatientAgeTextBox = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PatientLNTextBox = New System.Windows.Forms.TextBox()
        Me.PatientFNTextBox = New System.Windows.Forms.TextBox()
        Me.PatientIDTextBox = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.HomeButton = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.BackButton = New System.Windows.Forms.Button()
        Me.NextButton = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.UserIDLabel = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.UserIDLabel2 = New System.Windows.Forms.Label()
        Me.StringPassLabel = New System.Windows.Forms.Label()
        Me.PatientGroupBox.SuspendLayout()
        CType(Me.BIS425BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BIS425, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PatientGroupBox
        '
        Me.PatientGroupBox.BackColor = System.Drawing.Color.Transparent
        Me.PatientGroupBox.Controls.Add(Me.PatientDOBDateTimePicker)
        Me.PatientGroupBox.Controls.Add(Me.LocationComboBox)
        Me.PatientGroupBox.Controls.Add(Me.PatientMNLabel)
        Me.PatientGroupBox.Controls.Add(Me.MiddleNameTextBox)
        Me.PatientGroupBox.Controls.Add(Me.Label12)
        Me.PatientGroupBox.Controls.Add(Me.NotesTextBox)
        Me.PatientGroupBox.Controls.Add(Me.MedicationTextBox)
        Me.PatientGroupBox.Controls.Add(Me.PatientAgeTextBox)
        Me.PatientGroupBox.Controls.Add(Me.Label7)
        Me.PatientGroupBox.Controls.Add(Me.Label5)
        Me.PatientGroupBox.Controls.Add(Me.Label6)
        Me.PatientGroupBox.Controls.Add(Me.PatientLNTextBox)
        Me.PatientGroupBox.Controls.Add(Me.PatientFNTextBox)
        Me.PatientGroupBox.Controls.Add(Me.PatientIDTextBox)
        Me.PatientGroupBox.Controls.Add(Me.Label4)
        Me.PatientGroupBox.Controls.Add(Me.Label3)
        Me.PatientGroupBox.Controls.Add(Me.Label2)
        Me.PatientGroupBox.Controls.Add(Me.Label1)
        Me.PatientGroupBox.Font = New System.Drawing.Font("Book Antiqua", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PatientGroupBox.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.PatientGroupBox.Location = New System.Drawing.Point(52, 95)
        Me.PatientGroupBox.Name = "PatientGroupBox"
        Me.PatientGroupBox.Size = New System.Drawing.Size(454, 496)
        Me.PatientGroupBox.TabIndex = 1
        Me.PatientGroupBox.TabStop = False
        Me.PatientGroupBox.Text = "Patient Info:"
        '
        'PatientDOBDateTimePicker
        '
        Me.PatientDOBDateTimePicker.Location = New System.Drawing.Point(212, 193)
        Me.PatientDOBDateTimePicker.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PatientDOBDateTimePicker.Name = "PatientDOBDateTimePicker"
        Me.PatientDOBDateTimePicker.Size = New System.Drawing.Size(177, 41)
        Me.PatientDOBDateTimePicker.TabIndex = 27
        '
        'LocationComboBox
        '
        Me.LocationComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.LocationComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.LocationComboBox.Items.AddRange(New Object() {"CLINTON TOWNSHIP", "FORT GRATIOT", "NEW HAVEN"})
        Me.LocationComboBox.Location = New System.Drawing.Point(212, 324)
        Me.LocationComboBox.Name = "LocationComboBox"
        Me.LocationComboBox.Size = New System.Drawing.Size(166, 40)
        Me.LocationComboBox.TabIndex = 7
        '
        'BIS425BindingSource
        '
        Me.BIS425BindingSource.DataSource = Me.BIS425
        Me.BIS425BindingSource.Position = 0
        '
        'BIS425
        '
        Me.BIS425.DataSetName = "BIS425"
        Me.BIS425.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PatientMNLabel
        '
        Me.PatientMNLabel.BackColor = System.Drawing.Color.Transparent
        Me.PatientMNLabel.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PatientMNLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.PatientMNLabel.Location = New System.Drawing.Point(22, 116)
        Me.PatientMNLabel.Name = "PatientMNLabel"
        Me.PatientMNLabel.Size = New System.Drawing.Size(144, 32)
        Me.PatientMNLabel.TabIndex = 21
        Me.PatientMNLabel.Text = "Middle Inital:"
        Me.PatientMNLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'MiddleNameTextBox
        '
        Me.MiddleNameTextBox.Location = New System.Drawing.Point(212, 112)
        Me.MiddleNameTextBox.Name = "MiddleNameTextBox"
        Me.MiddleNameTextBox.Size = New System.Drawing.Size(41, 41)
        Me.MiddleNameTextBox.TabIndex = 2
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label12.Location = New System.Drawing.Point(22, 381)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(92, 32)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "Notes:"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NotesTextBox
        '
        Me.NotesTextBox.Location = New System.Drawing.Point(212, 364)
        Me.NotesTextBox.Multiline = True
        Me.NotesTextBox.Name = "NotesTextBox"
        Me.NotesTextBox.Size = New System.Drawing.Size(220, 100)
        Me.NotesTextBox.TabIndex = 8
        '
        'MedicationTextBox
        '
        Me.MedicationTextBox.Location = New System.Drawing.Point(212, 280)
        Me.MedicationTextBox.Name = "MedicationTextBox"
        Me.MedicationTextBox.Size = New System.Drawing.Size(102, 41)
        Me.MedicationTextBox.TabIndex = 6
        '
        'PatientAgeTextBox
        '
        Me.PatientAgeTextBox.Location = New System.Drawing.Point(212, 238)
        Me.PatientAgeTextBox.Name = "PatientAgeTextBox"
        Me.PatientAgeTextBox.Size = New System.Drawing.Size(102, 41)
        Me.PatientAgeTextBox.TabIndex = 5
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(22, 326)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(128, 32)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Location:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(22, 282)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(171, 32)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Medications:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(22, 240)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 32)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Age"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PatientLNTextBox
        '
        Me.PatientLNTextBox.Location = New System.Drawing.Point(212, 154)
        Me.PatientLNTextBox.Name = "PatientLNTextBox"
        Me.PatientLNTextBox.Size = New System.Drawing.Size(220, 41)
        Me.PatientLNTextBox.TabIndex = 3
        '
        'PatientFNTextBox
        '
        Me.PatientFNTextBox.Location = New System.Drawing.Point(212, 71)
        Me.PatientFNTextBox.Name = "PatientFNTextBox"
        Me.PatientFNTextBox.Size = New System.Drawing.Size(220, 41)
        Me.PatientFNTextBox.TabIndex = 1
        '
        'PatientIDTextBox
        '
        Me.PatientIDTextBox.Location = New System.Drawing.Point(212, 26)
        Me.PatientIDTextBox.MaxLength = 8
        Me.PatientIDTextBox.Name = "PatientIDTextBox"
        Me.PatientIDTextBox.ReadOnly = True
        Me.PatientIDTextBox.Size = New System.Drawing.Size(102, 41)
        Me.PatientIDTextBox.TabIndex = 4
        Me.PatientIDTextBox.TabStop = False
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(22, 198)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 32)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "D.O.B"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(22, 75)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(156, 32)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "First Name:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(22, 156)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(153, 32)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Last Name:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(22, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(144, 32)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Patient ID:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'HomeButton
        '
        Me.HomeButton.BackColor = System.Drawing.SystemColors.Window
        Me.HomeButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HomeButton.Location = New System.Drawing.Point(30, 607)
        Me.HomeButton.Name = "HomeButton"
        Me.HomeButton.Size = New System.Drawing.Size(124, 44)
        Me.HomeButton.TabIndex = 2
        Me.HomeButton.Text = "&Home"
        Me.HomeButton.UseVisualStyleBackColor = False
        '
        'ExitButton
        '
        Me.ExitButton.BackColor = System.Drawing.SystemColors.Window
        Me.ExitButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExitButton.Location = New System.Drawing.Point(420, 607)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(124, 44)
        Me.ExitButton.TabIndex = 3
        Me.ExitButton.Text = "E&xit"
        Me.ExitButton.UseVisualStyleBackColor = False
        '
        'BackButton
        '
        Me.BackButton.BackColor = System.Drawing.SystemColors.Window
        Me.BackButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BackButton.Location = New System.Drawing.Point(160, 607)
        Me.BackButton.Name = "BackButton"
        Me.BackButton.Size = New System.Drawing.Size(124, 44)
        Me.BackButton.TabIndex = 4
        Me.BackButton.Text = "&Back"
        Me.BackButton.UseVisualStyleBackColor = False
        '
        'NextButton
        '
        Me.NextButton.BackColor = System.Drawing.SystemColors.Window
        Me.NextButton.Font = New System.Drawing.Font("Book Antiqua", 10.125!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NextButton.Location = New System.Drawing.Point(290, 607)
        Me.NextButton.Name = "NextButton"
        Me.NextButton.Size = New System.Drawing.Size(124, 44)
        Me.NextButton.TabIndex = 5
        Me.NextButton.Text = "&Add"
        Me.NextButton.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.Location = New System.Drawing.Point(46, 22)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(259, 33)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "Patient Added By:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.Location = New System.Drawing.Point(49, 55)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(185, 33)
        Me.Label9.TabIndex = 23
        Me.Label9.Text = "Date Added:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'UserIDLabel
        '
        Me.UserIDLabel.AutoSize = True
        Me.UserIDLabel.BackColor = System.Drawing.Color.Transparent
        Me.UserIDLabel.Font = New System.Drawing.Font("Book Antiqua", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserIDLabel.ForeColor = System.Drawing.Color.Red
        Me.UserIDLabel.Location = New System.Drawing.Point(304, 23)
        Me.UserIDLabel.Name = "UserIDLabel"
        Me.UserIDLabel.Size = New System.Drawing.Size(0, 39)
        Me.UserIDLabel.TabIndex = 24
        Me.UserIDLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(264, 58)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(270, 31)
        Me.DateTimePicker1.TabIndex = 25
        '
        'UserIDLabel2
        '
        Me.UserIDLabel2.AutoSize = True
        Me.UserIDLabel2.Location = New System.Drawing.Point(310, 28)
        Me.UserIDLabel2.Name = "UserIDLabel2"
        Me.UserIDLabel2.Size = New System.Drawing.Size(0, 25)
        Me.UserIDLabel2.TabIndex = 26
        Me.UserIDLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'StringPassLabel
        '
        Me.StringPassLabel.BackColor = System.Drawing.Color.Transparent
        Me.StringPassLabel.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StringPassLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.StringPassLabel.Location = New System.Drawing.Point(311, 21)
        Me.StringPassLabel.Name = "StringPassLabel"
        Me.StringPassLabel.Size = New System.Drawing.Size(153, 32)
        Me.StringPassLabel.TabIndex = 29
        Me.StringPassLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'AddPatientForm
        '
        Me.AcceptButton = Me.NextButton
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(558, 663)
        Me.Controls.Add(Me.StringPassLabel)
        Me.Controls.Add(Me.UserIDLabel2)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.UserIDLabel)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.NextButton)
        Me.Controls.Add(Me.BackButton)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.HomeButton)
        Me.Controls.Add(Me.PatientGroupBox)
        Me.Name = "AddPatientForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ADD NEW PATIENT "
        Me.PatientGroupBox.ResumeLayout(False)
        Me.PatientGroupBox.PerformLayout()
        CType(Me.BIS425BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BIS425, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PatientGroupBox As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PatientLNTextBox As TextBox
    Friend WithEvents PatientFNTextBox As TextBox
    Friend WithEvents PatientIDTextBox As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents NotesTextBox As TextBox
    Friend WithEvents MedicationTextBox As TextBox
    Friend WithEvents PatientAgeTextBox As TextBox
    Friend WithEvents HomeButton As Button
    Friend WithEvents ExitButton As Button
    Friend WithEvents BackButton As Button
    Friend WithEvents NextButton As Button
    Friend WithEvents PatientMNLabel As Label
    Friend WithEvents MiddleNameTextBox As TextBox
    Friend WithEvents LocationComboBox As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents UserIDLabel As Label
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents UserIDLabel2 As Label
    Friend WithEvents PatientDOBDateTimePicker As DateTimePicker
    Friend WithEvents StringPassLabel As Label
    Friend WithEvents BIS425BindingSource As BindingSource
    Friend WithEvents BIS425 As BIS425
End Class
