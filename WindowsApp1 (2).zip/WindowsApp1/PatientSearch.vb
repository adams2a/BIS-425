﻿Public Class PatientSearch
    Public Property StringPass As String
    Private DB As New DBAccess
    Public SQLString As String
    Public DBreader As String
    Private currentreccord As Integer = 0

    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function

    Private Sub RefreshDB()
        PatientDataGridView.ReadOnly = True
        DB.ExecuteQuery("SELECT * FROM patient")
        If DB.Exception <> String.Empty Then
            MessageBox.Show(DB.Exception)
            Exit Sub
        End If
        PatientDataGridView.DataSource = DB.DBDataTable
    End Sub

    Private Sub PatientSearch_Load(sender As Object, e As EventArgs) Handles MyBase.Load
         RefreshDB()
        PatientDataGridView.ReadOnly = True
        DB.ExecuteQuery("SELECT person.personID, Person.PersonClient, person.BranchID, person.PersonFirstName,person.PersonMiddleInitial, person.PersonLastName, person.PersonGender, person.PersonPhoneNumber, person.PersonBirthDate, person.PersonAge, person.PersonType, person.PersonPassword, person.PersonEmail, person.PersonStreet, person.PersonCity, person.PersonZip, person.PersonState, person.EmergencyFirstName, person.EmergencyLastName, person.EmergencyPhoneNumber, person.CreateDate, patient.patientID, patient.DateEntered, patient.AdmittanceReason, patient.ApprovedGuests, patient.AdditionalNotes FROM person INNER JOIN patient on person.personID = patient.patientID WHERE patient.patientid LIKE ?")

        If DB.Exception <> String.Empty Then
            MessageBox.Show(DB.Exception)
            Exit Sub
        End If
        PatientDataGridView.DataSource = DB.DBDataTable
    End Sub
    Private Sub SearchPatient(PatientID As String)
        DB.AddParam("@PersonID", PatientID & "%")
        DB.ExecuteQuery("SELECT @person.personID, Person.PersonClient, person.BranchID, person.PersonFirstName,person.PersonMiddleInitial, person.PersonLastName, person.PersonGender, person.PersonPhoneNumber, person.PersonBirthDate, person.PersonAge, person.PersonType, person.PersonPassword, person.PersonEmail, person.PersonStreet, person.PersonCity, person.PersonZip, person.PersonState, person.EmergencyFirstName, person.EmergencyLastName, person.EmergencyPhoneNumber, person.CreateDate, patient.patientID, patient.DateEntered, patient.AdmittanceReason, patient.ApprovedGuests, patient.AdditionalNotes FROM person INNER JOIN patient on person.personID = patient.patientID WHERE patient.patientid LIKE ?")
        If DB.Exception <> String.Empty Then
            MessageBox.Show(DB.Exception)
            Exit Sub
        End If
        PatientDataGridView.DataSource = DB.DBDataTable
    End Sub

    Private Sub PatientSearch(PatientLastName As String)

        DB.AddParam("@PatientLastName", PatientLastName & "%")
        DB.ExecuteQuery("SELECT * FROM patient WHERE PatientLastName LIKE ?")
        If NotEmpty(DB.Exception) Then
            MessageBox.Show(DB.Exception)
            Exit Sub
        End If
        'fill data grid
        PatientDataGridView.DataSource = DB.DBDataTable

    End Sub



    Private Sub SelectPatient(LastName As String, FirstName As String)
        DB.AddParam("@PatientFirstName", FirstName)
        DB.AddParam("@PatientLastName", LastName)

        DB.ExecuteQuery("SELECT PatientID, PatientFirstName, PatientLastName FROM patient WHERE PatientFirstName = ? AND PatientLastName = ?")

        If DB.Exception <> String.Empty Then
            MessageBox.Show(DB.Exception)
            Exit Sub
        End If
        Dim SearchedRow As DataRow = DB.DBDataTable.Rows(0)

        PatientIDTextBox.Text = SearchedRow!PatientID
        PatientNameTextBox.Text = SearchedRow!PatientLastName & "," & SearchedRow!PatientFirstName

        DeletePatientToolStripMenuItem.Enabled = True

    End Sub

    Private Sub PatientDataGridView_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles PatientDataGridView.CellClick
        If e.ColumnIndex < 0 Or e.RowIndex < 0 Then
            Exit Sub
        End If

        SelectPatient(PatientDataGridView.Item(3, e.RowIndex).Value, PatientDataGridView.Item(1, e.RowIndex).Value)
    End Sub
    Private Sub DeletePatient()
        If MessageBox.Show("Are you sure you want to delete the selected patient record?", "Delete Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) =
                DialogResult.No Then
            Exit Sub
        End If

        DB.AddParam("@PatientID", PatientIDTextBox.Text)
        DB.ExecuteQuery("DELETE FROM patient WHERE patientID = ?")

        If DB.Exception <> String.Empty Then
            MessageBox.Show(DB.Exception)
            Exit Sub
        End If
        MessageBox.Show("The patient record has been successfully deleted.", "Delete Sucessful", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        PatientIDTextBox.Clear()
        PatientNameTextBox.Clear()
        DeletePatientToolStripMenuItem.Enabled = False

        RefreshDB()

    End Sub

    Private Sub DeletePatientToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeletePatientToolStripMenuItem.Click
        DeletePatient()
    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub SearchPatientIDTextBox_TextChanged(sender As Object, e As EventArgs) Handles SearchPatientIDTextBox.TextChanged
        SearchPatient(SearchPatientIDTextBox.Text)
    End Sub

    Private Sub PatientComboBox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles PatientComboBox.SelectedIndexChanged

    End Sub

    Private Sub Label_Click(sender As Object, e As EventArgs) Handles Label.Click

    End Sub

    Private Sub AddPatientToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddPatientToolStripMenuItem.Click
        PatientIDTextBox.Enabled = True
        PatientNameTextBox.Enabled = True
        PatientComboBox.Enabled = False
        SearchPatientIDTextBox.Enabled = False
        MessageBox.Show("Please search by Patient ID or Patient Last Name")

    End Sub

    Private Sub SearchButton_Click(sender As Object, e As EventArgs) Handles SearchButton.Click

    End Sub

    Private Sub PatientIDTextBox_TextChanged(sender As Object, e As EventArgs) Handles PatientIDTextBox.TextChanged

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub PatientNameTextBox_TextChanged(sender As Object, e As EventArgs) Handles PatientNameTextBox.TextChanged

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub PatientDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles PatientDataGridView.CellContentClick

    End Sub
end Class
