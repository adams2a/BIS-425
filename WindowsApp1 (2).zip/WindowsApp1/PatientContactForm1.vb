﻿Public Class PatientContactInfoForm
    Public Property StringPass As String

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Dim result = MessageBox.Show("All unsaved data and changes will be lost." & vbCrLf & "Are you sure you want to exit the patient entry form?", "Are you sure?", MessageBoxButtons.YesNoCancel)
        If result = DialogResult.Yes Then

            AddPatientForm.Close()
            HomeForm.Show()
            Me.Close()
        End If
    End Sub

    Private Sub NextButton_Click(sender As Object, e As EventArgs) Handles NextButton.Click
        If ContactFNTextBox.Text = "" Then
            MessageBox.Show("First name textbox cannot be left empty", "Missing Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ContactFNTextBox.Focus()
        ElseIf ContactMITextBox.text = "" Then
            MessageBox.Show("Middle name textbox cannot be left empty", "Missing Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ContactMITextBox.Focus()
        ElseIf ContactlnTextBox.text = "" Then
            MessageBox.Show("Last name textbox cannot be left empty", "Missing Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ContactLNTextBox.Focus()
        ElseIf RelationshipTextBox.text = "" Then
            MessageBox.Show("Contact relationship textbox cannot be left Empty.", "Missing Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            RelationshipTextBox.Focus()
        ElseIf ContactMethodComboBox.text = "" Then
            MessageBox.Show("Please select the best method to contact", "Missing Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ContactMethodComboBox.Focus()
        End If




        Dim obj As New PatientBillingForm
        obj.ShowDialog()
        Me.Hide()
    End Sub

    Private Sub BackButton_Click(sender As Object, e As EventArgs) Handles BackButton.Click
        AddPatientForm.Show()
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles ClearButton.Click
        ContactFNTextBox.Text = ""
        ContactLNTextBox.Text = ""
        ContactMITextBox.Text = ""
        RelationshipTextBox.Text = ""
        HomeMaskedTextBox.Text = ""
        CellMaskedTextBox.Text = ""
        WorkMaskedTextBox1.Text = ""
        ContactMethodComboBox.Text = ""
        ContactFNTextBox.Focus()
    End Sub

    Private Sub PidTextBox_TextChanged(sender As Object, e As EventArgs) Handles PidTextBox.TextChanged
        Me.Text = AddPatientForm.PatientIDTextBox.Text
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        Me.Text = AddPatientForm.PatientFNTextBox.Text
    End Sub
End Class