﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PersonsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PersonsForm))
        Me.NewPersonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeletePersonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditPersonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PersonComboBox = New System.Windows.Forms.ComboBox()
        Me.Label = New System.Windows.Forms.Label()
        Me.PersonDataGridView = New System.Windows.Forms.DataGridView()
        Me.SearchPersonTextBox = New System.Windows.Forms.TextBox()
        Me.SearchButton = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.PersonIDTextBox = New System.Windows.Forms.TextBox()
        Me.PersonNameTextBox = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.PersonDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'NewPersonToolStripMenuItem
        '
        Me.NewPersonToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NewPersonToolStripMenuItem.Name = "NewPersonToolStripMenuItem"
        Me.NewPersonToolStripMenuItem.Size = New System.Drawing.Size(157, 32)
        Me.NewPersonToolStripMenuItem.Text = "&New &Person"
        '
        'DeletePersonToolStripMenuItem
        '
        Me.DeletePersonToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeletePersonToolStripMenuItem.Name = "DeletePersonToolStripMenuItem"
        Me.DeletePersonToolStripMenuItem.Size = New System.Drawing.Size(177, 32)
        Me.DeletePersonToolStripMenuItem.Text = "&Delete &Person"
        '
        'EditPersonToolStripMenuItem
        '
        Me.EditPersonToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EditPersonToolStripMenuItem.Name = "EditPersonToolStripMenuItem"
        Me.EditPersonToolStripMenuItem.Size = New System.Drawing.Size(151, 32)
        Me.EditPersonToolStripMenuItem.Text = "&Edit &Person"
        '
        'PersonComboBox
        '
        Me.PersonComboBox.FormattingEnabled = True
        Me.PersonComboBox.Location = New System.Drawing.Point(68, 109)
        Me.PersonComboBox.Name = "PersonComboBox"
        Me.PersonComboBox.Size = New System.Drawing.Size(435, 33)
        Me.PersonComboBox.TabIndex = 44
        '
        'Label
        '
        Me.Label.AutoSize = True
        Me.Label.BackColor = System.Drawing.Color.Transparent
        Me.Label.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label.ForeColor = System.Drawing.SystemColors.Control
        Me.Label.Location = New System.Drawing.Point(85, 73)
        Me.Label.Name = "Label"
        Me.Label.Size = New System.Drawing.Size(200, 33)
        Me.Label.TabIndex = 41
        Me.Label.Text = "Person Name:"
        '
        'PersonDataGridView
        '
        Me.PersonDataGridView.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.PersonDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.PersonDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.PersonDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.PersonDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.PersonDataGridView.GridColor = System.Drawing.Color.DeepSkyBlue
        Me.PersonDataGridView.Location = New System.Drawing.Point(30, 221)
        Me.PersonDataGridView.Name = "PersonDataGridView"
        Me.PersonDataGridView.RowTemplate.Height = 33
        Me.PersonDataGridView.Size = New System.Drawing.Size(1303, 495)
        Me.PersonDataGridView.TabIndex = 40
        '
        'SearchPersonTextBox
        '
        Me.SearchPersonTextBox.Location = New System.Drawing.Point(68, 167)
        Me.SearchPersonTextBox.Name = "SearchPersonTextBox"
        Me.SearchPersonTextBox.Size = New System.Drawing.Size(276, 31)
        Me.SearchPersonTextBox.TabIndex = 37
        '
        'SearchButton
        '
        Me.SearchButton.Font = New System.Drawing.Font("Book Antiqua", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SearchButton.Location = New System.Drawing.Point(350, 167)
        Me.SearchButton.Name = "SearchButton"
        Me.SearchButton.Size = New System.Drawing.Size(153, 36)
        Me.SearchButton.TabIndex = 45
        Me.SearchButton.Text = "&Search"
        Me.SearchButton.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label13.Location = New System.Drawing.Point(543, 134)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(155, 33)
        Me.Label13.TabIndex = 43
        Me.Label13.Text = "Person ID:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Book Antiqua", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label14.Location = New System.Drawing.Point(845, 135)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(200, 33)
        Me.Label14.TabIndex = 42
        Me.Label14.Text = "Person Name:"
        '
        'PersonIDTextBox
        '
        Me.PersonIDTextBox.Location = New System.Drawing.Point(708, 135)
        Me.PersonIDTextBox.Name = "PersonIDTextBox"
        Me.PersonIDTextBox.ReadOnly = True
        Me.PersonIDTextBox.Size = New System.Drawing.Size(131, 31)
        Me.PersonIDTextBox.TabIndex = 39
        '
        'PersonNameTextBox
        '
        Me.PersonNameTextBox.Location = New System.Drawing.Point(1055, 136)
        Me.PersonNameTextBox.Name = "PersonNameTextBox"
        Me.PersonNameTextBox.Size = New System.Drawing.Size(251, 31)
        Me.PersonNameTextBox.TabIndex = 38
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Aqua
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewPersonToolStripMenuItem, Me.DeletePersonToolStripMenuItem, Me.EditPersonToolStripMenuItem, Me.CloseToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1345, 36)
        Me.MenuStrip1.TabIndex = 46
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(85, 32)
        Me.CloseToolStripMenuItem.Text = "&Close"
        '
        'PersonsForm
        '
        Me.AcceptButton = Me.SearchButton
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1345, 728)
        Me.Controls.Add(Me.PersonComboBox)
        Me.Controls.Add(Me.Label)
        Me.Controls.Add(Me.PersonDataGridView)
        Me.Controls.Add(Me.SearchPersonTextBox)
        Me.Controls.Add(Me.SearchButton)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.PersonIDTextBox)
        Me.Controls.Add(Me.PersonNameTextBox)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "PersonsForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "PersonsForm"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.PersonDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents NewPersonToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeletePersonToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditPersonToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PersonComboBox As ComboBox
    Friend WithEvents Label As Label
    Friend WithEvents PersonDataGridView As DataGridView
    Friend WithEvents SearchPersonTextBox As TextBox
    Friend WithEvents SearchButton As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents PersonIDTextBox As TextBox
    Friend WithEvents PersonNameTextBox As TextBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents CloseToolStripMenuItem As ToolStripMenuItem
End Class
