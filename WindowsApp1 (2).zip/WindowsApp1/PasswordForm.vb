﻿Imports System.Data.Odbc
Public Class Passwordform
    Public Property StringPass As String
    Private DB As New DBAccess
    Private Sub PasswordForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        UserIDLabel.Text = UserID
    End Sub
    Private Sub CancelButton_Click(sender As Object, e As EventArgs) Handles CancelButton.Click
        Me.Close()
        HomeForm.Show()
    End Sub

    Private Sub OKButton_Click(sender As Object, e As EventArgs) Handles OKButton.Click
        If PasswordTextBox.Text = String.Empty Then
            MessageBox.Show("Password cannot be left empty!")
            PasswordTextBox.Select()
            Exit Sub

        Else
            DB.AddParam("@PersonPassword", PasswordTextBox.Text)
            DB.ExecuteQuery("Select * from person where PersonPassword = ?")

            If DB.Exception <> String.Empty Then
                MessageBox.Show(DB.Exception)
                Exit Sub
            Else
                If DB.RecordCount = 0 Then
                    MessageBox.Show("The user ID and password do not match.")
                    PasswordTextBox.Clear()
                    Exit Sub
                Else
                    MessageBox.Show(String.Format("User Validation completed!" & vbNewLine & "Welcome {0}.", UserIDLabel.Text))
                    Dim obj As New PatientSearch
                    obj.StringPass = UserIDLabel2.Text
                    Me.Close()
                    obj.ShowDialog()
                    'PatientSearch.Show()
                End If
            End If
        End If

    End Sub

    Private Sub PasswordTextBox_TextChanged(sender As Object, e As EventArgs) Handles PasswordTextBox.TextChanged
        Me.Focus()
    End Sub

End Class