﻿Public Class Form1


    Private Sub SplitContainer1_Panel1_Paint(sender As Object, e As PaintEventArgs) Handles SplitContainer1.Panel1.Paint

    End Sub

    Private Sub SplitContainer1_Panel1_Paint_1(sender As Object, e As PaintEventArgs) Handles SplitContainer1.Panel1.Paint

    End Sub

    Private Sub PatientsButton_Click(sender As Object, e As EventArgs) Handles PatientsButton.Click
        Dim PatientSearch As New Form
        PatientSearch.TopLevel = False
        SplitContainer1.Panel2.Controls.Add(PatientSearch)
        PatientSearch.Show()
        PatientSearch.Show()
    End Sub

    Private Sub PersonsButton_Click(sender As Object, e As EventArgs) Handles PersonsButton.Click
        Dim PersonForm As New Form
        PersonForm.TopLevel = False
        SplitContainer1.Panel2.Controls.Add(PersonForm)
        PersonForm.Show()
    End Sub
End Class