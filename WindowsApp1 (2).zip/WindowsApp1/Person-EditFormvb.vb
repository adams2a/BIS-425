﻿Public Class Person_EditFormvb
    Private DB As New DBAccess
    Private CurrentRecord As Integer = 0
    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function
    Private Sub Person_EditFormvb_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetPerson()
    End Sub
    Private Sub GetPerson()
        DB.ExecuteQuery("SELECT * FROM person")
        If NotEmpty(DB.Exception) OrElse DB.RecordCount < 1 Then
            MessageBox.Show(DB.Exception)
            Exit Sub
        End If
        GetRecord()
    End Sub
    Private Sub GetRecord()
        If DB.DBDataTable.Rows.Count < 1 OrElse CurrentRecord >
DB.DBDataTable.Rows.Count - 1 Then
            Exit Sub
        End If
        Dim ADataRow As DataRow = DB.DBDataTable.Rows(CurrentRecord)
        PersonIDTextBox.Text = ADataRow("PersonID").ToString
        PersonClientTextBox.Text = ADataRow("PersonClient").ToString
        PersonBranchIDComboBox.Text = ADataRow("BranchID").ToString
        PersonFNTextBox.Text = ADataRow("PersonFirstName").ToString
        PersonMiddleTextBox.Text = ADataRow("PersonMiddleInitial")
        PersonLNTextBox.Text = ADataRow("PersonLastName")
        PersonGenderComboBox.Text = ADataRow("PersonGender").ToString
        PersonPhoneMaskedTextBox.Text = ADataRow("PersonPhoneNumber").ToString
        PersonDOBDateTimePicker.Text = ADataRow("PersonBirthDate").ToString
        PersonAgeTextBox.Text = ADataRow("PersonAge").ToString
        PersonTypeComboBox.Text = ADataRow("PersonType").ToString
        PasswordTextBox.Text = ADataRow("PersonPassword").ToString
        PersonEmailTextBox.Text = ADataRow("PersonEmail").ToString

        PersonStreetTextBox.Text = ADataRow("PersonStreet").ToString
        PersonCityTextBox.Text = ADataRow("PersonCity").ToString
        PersonStateComboBox.Text = ADataRow("PersonState").ToString
        PersonZipMaskedTextBox.Text = ADataRow("PersonZip").ToString
        ContactFNTextBox.Text = ADataRow("EmergencyFirstName").ToString
        ContactLNTextBox.Text = ADataRow("EmergencyLastName").ToString
        PhoneMaskedTextBox.Text = ADataRow("EmergencyPhoneNumber").ToString
        DateAddedTextBox.Text = ADataRow("CreateDate").ToString

    End Sub
    Private Sub NextRecord(StepValue As Integer)
        CurrentRecord += StepValue
        If CurrentRecord > DB.DBDataTable.Rows.Count - 1 Then
            CurrentRecord = 0
        End If
        If CurrentRecord < 0 Then
            CurrentRecord = DB.DBDataTable.Rows.Count - 1
        End If
        GetRecord()
    End Sub

    Private Sub FirstButton_Click(sender As Object, e As EventArgs) Handles FirstButton.Click
        CurrentRecord = 0
        GetRecord()
    End Sub

    Private Sub PreviousButton_Click(sender As Object, e As EventArgs) Handles PreviousButton.Click
        NextRecord(-1)
    End Sub
    Private Sub NextButton_Click(sender As System.Object, e As System.EventArgs) Handles NextButton.Click
        NextRecord(1)
    End Sub
    Private Sub LastButton_Click(sender As System.Object, e As System.EventArgs) Handles LastButton.Click
        CurrentRecord = DB.DBDataTable.Rows.Count - 1
        GetRecord()
    End Sub
    Private Sub SetFieldsEditable(ByVal Switch As Boolean)
        PersonPasswordTextBox.Enabled = Switch
        PasswordTextBox.Enabled = Switch
        DateAddedTextBox.Enabled = Switch
        PersonFNTextBox.Enabled = Switch
        PersonMiddleTextBox.Enabled = Switch
        PersonLNTextBox.Enabled = Switch
        PersonDOBDateTimePicker.Enabled = Switch
        PersonEmailTextBox.Enabled = Switch
        PersonBranchIDComboBox.Enabled = Switch
        PersonGenderComboBox.Enabled = Switch
        PersonPhoneMaskedTextBox.Enabled = Switch
        PersonTypeComboBox.Enabled = Switch
        PersonStreetTextBox.Enabled = Switch
        PersonCityTextBox.Enabled = Switch
        PersonStateComboBox.Enabled = Switch
        PersonZipMaskedTextBox.Enabled = Switch
        ContactFNTextBox.Enabled = Switch
        ContactLNTextBox.Enabled = Switch
        PhoneMaskedTextBox.Enabled = Switch
    End Sub
    Private Sub EditButton_Click(sender As System.Object, e As System.EventArgs) Handles EditButton.Click
        SetFieldsEditable(True)
    End Sub
    Private Sub UpdateRecord()
        If String.IsNullOrEmpty(PersonIDTextBox.Text) Then
            Exit Sub
        End If
        DB.AddParam("@PersonID", PersonIDTextBox.Text)
        DB.AddParam("@PersonClient", PersonClientTextBox.Text)
        DB.AddParam("@BranchID", PersonBranchIDComboBox.Text)
        DB.AddParam("@PersonFirstName", PersonFNTextBox.Text)
        DB.AddParam("@PersonMiddleInitial", PersonMiddleTextBox.Text)
        DB.AddParam("@PersonLastName", PersonLNTextBox.Text)
        DB.AddParam("@PersonGender", PersonGenderComboBox.Text)
        DB.AddParam("@PersonPhoneNumber", PersonPhoneMaskedTextBox.Text)
        DB.AddParam("@PersonBirthDate", PersonDOBDateTimePicker.Value)
        DB.AddParam("@PersonAge", PersonAgeTextBox.Text)
        DB.AddParam("@PersonType", PersonTypeComboBox.Text)
        DB.AddParam("@PersonPassword", PersonPasswordTextBox.Text)
        DB.AddParam("@Personemail", PersonEmailTextBox.Text)
        'Add address parameters
        DB.AddParam("@PersonStreet", PersonStreetTextBox.Text)
        DB.AddParam("@PersonCity", PersonCityTextBox.Text)
        DB.AddParam("@PersonZip", PersonZipMaskedTextBox.Text)
        DB.AddParam("@PersonState", PersonStateComboBox.Text)
        'add contact emergency parameters
        DB.AddParam("@EmergencyFirstName", ContactFNTextBox.Text)
        DB.AddParam("@EmergencyLastName", ContactLNTextBox.Text)
        DB.AddParam("@EmergencyPhoneNumber", PhoneMaskedTextBox.Text)
        DB.AddParam("@CreateDate", DateAddedTextBox.Text)

        DB.ExecuteQuery("UPDATE person SET PersonClient = ?, BranchID = ?, PersonFirstName = ?, PersonMiddleInitial = ?, PersonLastName = ?, PersonGender = ?, PersonPhoneNumber = ?, PersonBirthDate = ?, PersonAge = ?, PersonType = ?, PersonPassword = ?, PersonEmail = ?, PersonStreet = ?, PersonCity = ?, PersonZip = ?, PersonState = ?, EmergencyFirstName = ?, EmergencyLastName = ?, EmergencyPhoneNumber = ?, CreateDate = ? WHERE personid = ?")

        If NotEmpty(DB.Exception) Then
            MessageBox.Show(DB.Exception)
            Exit Sub
        Else
            MessageBox.Show("Person record has been updated successfully.")
        End If
        GetPerson()
    End Sub
    Private Sub SaveButton_Click(sender As System.Object, e As System.EventArgs) Handles SaveButton.Click
        UpdateRecord()
        SetFieldsEditable(False)
    End Sub

    Private Sub CancelButton_Click(sender As Object, e As EventArgs) Handles CancelButton.Click
        Me.Close()
    End Sub
End Class
